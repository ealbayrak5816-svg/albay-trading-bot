package com.albay.tradingbot;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

/** Ön plan servisi: uygulama arka planda iken sistemin süreci kapatmasını önler. */
public class BotService extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NativeBridge.createChannels(this);
        Notification n = new NotificationCompat.Builder(this, NativeBridge.CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Albay Trading Bot")
                .setContentText("Piyasalar canlı takip ediliyor")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(NativeBridge.openApp(this))
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
