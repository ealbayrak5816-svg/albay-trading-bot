package com.albay.tradingbot;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.webkit.JavascriptInterface;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/** HTML uygulamasının çağırdığı yerel köprü: window.AlbayBot */
public class NativeBridge {

    static final String CH_SIGNALS = "albay_signals";
    static final String CH_SERVICE = "albay_service";
    private static int nextId = 1000;
    private final Activity activity;

    NativeBridge(Activity a) { this.activity = a; }

    static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel sig = new NotificationChannel(CH_SIGNALS, "Sinyaller", NotificationManager.IMPORTANCE_HIGH);
        sig.setDescription("Yeni sinyal, TP ve stop bildirimleri");
        sig.enableVibration(true);
        nm.createNotificationChannel(sig);
        NotificationChannel svc = new NotificationChannel(CH_SERVICE, "Bot çalışıyor", NotificationManager.IMPORTANCE_LOW);
        svc.setDescription("Canlı veri takibinin arka planda sürdüğünü gösterir");
        nm.createNotificationChannel(svc);
    }

    static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    @JavascriptInterface
    public void notify(String title, String body) {
        if (!NotificationManagerCompat.from(activity).areNotificationsEnabled()) return;
        NotificationCompat.Builder b = new NotificationCompat.Builder(activity, CH_SIGNALS)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(openApp(activity));
        try { NotificationManagerCompat.from(activity).notify(nextId++, b.build()); }
        catch (SecurityException ignored) { }
    }

    @JavascriptInterface
    public void vibrate(int ms) {
        Vibrator v = activity.getSystemService(Vibrator.class);
        if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(30, ms), VibrationEffect.DEFAULT_AMPLITUDE));
    }

    @JavascriptInterface
    public boolean notificationsEnabled() {
        return NotificationManagerCompat.from(activity).areNotificationsEnabled();
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        activity.runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && activity instanceof MainActivity) ((MainActivity) activity).askNotificationPermission();
        });
    }

    @JavascriptInterface
    public String appVersion() { return "1.0"; }
}
