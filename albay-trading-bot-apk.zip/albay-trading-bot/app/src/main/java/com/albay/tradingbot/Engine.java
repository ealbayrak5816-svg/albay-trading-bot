package com.albay.tradingbot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Albay Trading Bot analiz motoru — web uygulamasındaki JavaScript motorunun birebir Java karşılığı.
 * 5 model: Likidite, SuperTrend, Smart Money, Order Block, Fibonacci. Uygulama kapalıyken arka planda çalışır.
 */
final class Engine {

    static final String[] MODELS = {"liq", "st", "smc", "ob", "fib"};
    static final int MIN_SCORE = 3;

    static final class C {
        final long t; final double o, h, l, c, v;
        C(long t, double o, double h, double l, double c, double v) { this.t = t; this.o = o; this.h = h; this.l = l; this.c = c; this.v = v; }
    }
    static final class P { final int i; final double p; P(int i, double p) { this.i = i; this.p = p; } }
    static final class Lv { final double p; final int touches; Lv(double p, int t) { this.p = p; this.touches = t; } }
    static final class Sw { final List<P> highs = new ArrayList<>(), lows = new ArrayList<>(); }

    static final class Ctx {
        List<C> c; int n; double close, A, ema200 = Double.NaN, avgVol, volaMult, volaAdj; int htfTrend; boolean choppy;
        List<Lv> highPools, lowPools; long barTime;
    }
    static final class Setup {
        String side; double stop; long sigBar; C sigCandle; double bonus; double[] fixed;
    }
    static final class Sig {
        String model, side, strength; double entry, stop, risk, rr; double[] tp; int score; long sigBar;
    }
    static final class Mo { boolean ok, above; int pts; double e20; }

    /* ---------------- İndikatörler ---------------- */
    static double[] ema(double[] v, int len) {
        if (v.length < len) return null;
        double k = 2.0 / (len + 1), e = 0;
        for (int i = 0; i < len; i++) e += v[i];
        e /= len;
        double[] out = new double[v.length];
        Arrays.fill(out, Double.NaN);
        out[len - 1] = e;
        for (int i = len; i < v.length; i++) { e = v[i] * k + e * (1 - k); out[i] = e; }
        return out;
    }

    static double[] atrW(List<C> c, int len) {
        double[] out = new double[c.size()];
        Arrays.fill(out, Double.NaN);
        double sum = 0, a = Double.NaN;
        for (int i = 1; i < c.size(); i++) {
            C k = c.get(i), p = c.get(i - 1);
            double tr = Math.max(k.h - k.l, Math.max(Math.abs(k.h - p.c), Math.abs(k.l - p.c)));
            if (Double.isNaN(a)) { sum += tr; if (i == len) { a = sum / len; out[i] = a; } }
            else { a = (a * (len - 1) + tr) / len; out[i] = a; }
        }
        return out;
    }

    static Sw findSwings(List<C> c, int lb) {
        Sw s = new Sw();
        for (int i = lb; i < c.size() - lb; i++) {
            boolean h = true, l = true;
            for (int j = 1; j <= lb; j++) {
                if (c.get(i).h <= c.get(i - j).h || c.get(i).h <= c.get(i + j).h) h = false;
                if (c.get(i).l >= c.get(i - j).l || c.get(i).l >= c.get(i + j).l) l = false;
            }
            if (h) s.highs.add(new P(i, c.get(i).h));
            if (l) s.lows.add(new P(i, c.get(i).l));
        }
        return s;
    }

    static List<Lv> cluster(List<P> pts, double tol, boolean high) {
        List<P> s = new ArrayList<>(pts);
        s.sort((a, b) -> Double.compare(a.p, b.p));
        List<Lv> out = new ArrayList<>();
        List<P> g = new ArrayList<>();
        for (P pt : s) {
            if (!g.isEmpty() && pt.p - g.get(g.size() - 1).p > tol) { out.add(mk(g, high)); g = new ArrayList<>(); }
            g.add(pt);
        }
        if (!g.isEmpty()) out.add(mk(g, high));
        return out;
    }
    private static Lv mk(List<P> g, boolean high) {
        double v = high ? -Double.MAX_VALUE : Double.MAX_VALUE;
        for (P p : g) v = high ? Math.max(v, p.p) : Math.min(v, p.p);
        return new Lv(v, g.size());
    }

    /** {dir[], line[]} — iş parçacığı güvenli */
    static Object[] superTrend(List<C> c, int len, double mult) {
        double[] at = atrW(c, len);
        int[] dir = new int[c.size()];
        double[] line = new double[c.size()];
        Arrays.fill(line, Double.NaN);
        double fu = Double.NaN, fl = Double.NaN; int d = 1;
        for (int i = 1; i < c.size(); i++) {
            if (Double.isNaN(at[i])) continue;
            C k = c.get(i);
            double hl2 = (k.h + k.l) / 2, bu = hl2 + mult * at[i], bl = hl2 - mult * at[i], pc = c.get(i - 1).c;
            fu = (Double.isNaN(fu) || bu < fu || pc > fu) ? bu : fu;
            fl = (Double.isNaN(fl) || bl > fl || pc < fl) ? bl : fl;
            if (d == 1 && k.c < fl) d = -1; else if (d == -1 && k.c > fu) d = 1;
            dir[i] = d; line[i] = d == 1 ? fl : fu;
        }
        return new Object[]{dir, line};
    }

    static double rsi(double[] v, int len) {
        if (v.length <= len) return 50;
        double g = 0, l = 0;
        for (int i = 1; i <= len; i++) { double d = v[i] - v[i - 1]; if (d > 0) g += d; else l -= d; }
        g /= len; l /= len;
        for (int i = len + 1; i < v.length; i++) { double d = v[i] - v[i - 1]; g = (g * (len - 1) + Math.max(d, 0)) / len; l = (l * (len - 1) + Math.max(-d, 0)) / len; }
        return l == 0 ? 100 : 100 - 100 / (1 + g / l);
    }

    static Mo momentum(List<C> c, boolean L) {
        Mo m = new Mo();
        int n = c.size() - 1;
        if (n < 40) return m;
        double[] cl = closes(c);
        double r = rsi(cl, 14);
        double[] e12 = ema(cl, 12), e26 = ema(cl, 26);
        List<Double> mac = new ArrayList<>();
        for (int i = 0; i < cl.length; i++) if (!Double.isNaN(e12[i]) && !Double.isNaN(e26[i])) mac.add(e12[i] - e26[i]);
        double[] macd = new double[mac.size()];
        for (int i = 0; i < macd.length; i++) macd[i] = mac.get(i);
        double[] sg = ema(macd, 9);
        double hist = macd[macd.length - 1] - sg[sg.length - 1], histPrev = macd[macd.length - 2] - sg[sg.length - 2];
        double e20 = ema(cl, 20)[n];
        double avg = 0; int cnt = 0;
        for (int i = c.size() - 23; i < c.size() - 3; i++) if (i >= 0) { avg += c.get(i).v; cnt++; }
        avg = cnt > 0 ? avg / cnt : 0;
        double vr = avg > 0 ? (c.get(n).v + c.get(n - 1).v + c.get(n - 2).v) / 3 / avg : 1;
        boolean above = L ? cl[n] > e20 : cl[n] < e20;
        int pts = 0;
        if (L ? r > 55 : r < 45) pts++;
        if (L ? (hist > 0 && hist >= histPrev) : (hist < 0 && hist <= histPrev)) pts++;
        if (above) pts++;
        if (vr >= 1.0) pts++;
        m.ok = pts >= 3 && above; m.above = above; m.pts = pts; m.e20 = e20;
        return m;
    }

    /** Runner: {exit(1/0), trail, price} */
    static double[] runnerCheck(boolean L, double stop, List<C> closed) {
        int n = closed.size() - 1;
        if (n < 40) return null;
        Mo mo = momentum(closed, L);
        double at = atrW(closed, 14)[n];
        double trail = L ? Math.max(stop, mo.e20 - 0.5 * at) : Math.min(stop, mo.e20 + 0.5 * at);
        boolean exit = !mo.above || mo.pts <= 1;
        return new double[]{exit ? 1 : 0, trail, closed.get(n).c};
    }

    static double[] closes(List<C> c) { double[] v = new double[c.size()]; for (int i = 0; i < v.length; i++) v[i] = c.get(i).c; return v; }
    static <T> List<T> tail(List<T> l, int n) { return l.subList(Math.max(0, l.size() - n), l.size()); }

    /* ---------------- Bağlam ---------------- */
    static Ctx buildCtx(List<C> c, List<C> htf) {
        Ctx x = new Ctx();
        x.c = c; x.n = c.size() - 1; x.close = c.get(x.n).c; x.barTime = c.get(x.n).t;
        double[] at = atrW(c, 14);
        x.A = at[x.n];
        List<Double> hist = new ArrayList<>();
        for (int i = Math.max(0, at.length - 100); i < at.length; i++) if (!Double.isNaN(at[i])) hist.add(at[i]);
        Collections.sort(hist);
        double med = hist.isEmpty() ? x.A : hist.get(hist.size() / 2);
        double ratio = x.A / med;
        if (ratio >= 1.8) { x.volaMult = 0.35; x.volaAdj = -2; }
        else if (ratio >= 1.3) { x.volaMult = 0.6; x.volaAdj = -1; }
        else if (ratio <= 0.7) { x.volaMult = 1; x.volaAdj = 0; }
        else { x.volaMult = 1; x.volaAdj = 0.5; }
        double wick = 0; List<C> ten = tail(c, 10);
        for (C k : ten) { double r = k.h - k.l; if (r == 0) r = 1e-12; wick += (r - Math.abs(k.c - k.o)) / r; }
        wick /= ten.size();
        x.choppy = wick > 0.62;
        if (x.choppy) { x.volaMult = Math.round(x.volaMult * 0.8 * 100) / 100.0; x.volaAdj -= 1; }

        double[] e200 = ema(closes(c), 200);
        if (e200 != null) x.ema200 = e200[x.n];
        x.htfTrend = 0;
        if (htf != null && htf.size() > 55) {
            double[] hc = closes(htf); double[] e = ema(hc, 50);
            if (e != null) {
                double now = e[e.length - 1], prev = e[e.length - 4], p = hc[hc.length - 1];
                if (p > now && now >= prev) x.htfTrend = 1; else if (p < now && now <= prev) x.htfTrend = -1;
            }
        }
        double s = 0; int cnt = 0;
        for (int i = c.size() - 21; i < c.size() - 1; i++) if (i >= 0) { s += c.get(i).v; cnt++; }
        x.avgVol = cnt > 0 ? s / cnt : 0;
        List<C> w = tail(c, 120);
        Sw sw = findSwings(w, 2);
        x.highPools = cluster(sw.highs, x.A * 0.15, true);
        x.lowPools = cluster(sw.lows, x.A * 0.15, false);
        return x;
    }

    /* ---------------- Modeller ---------------- */
    static Setup liq(Ctx x) {
        List<C> c = x.c; int N = 3; double A = x.A, close = x.close;
        List<C> bw = c.subList(Math.max(0, c.size() - (80 + N)), c.size() - N);
        Sw sw = findSwings(bw, 2);
        List<Lv> hp = cluster(sw.highs, A * 0.15, true), lp = cluster(sw.lows, A * 0.15, false);
        List<C> recent = tail(c, N);
        Lv bL = null, bS = null; C kL = null, kS = null; int riL = -1, riS = -1;
        for (int ri = 0; ri < recent.size(); ri++) {
            C k = recent.get(ri);
            for (Lv lv : lp) if (k.l < lv.p && k.c > lv.p && close > lv.p && (bL == null || lv.touches > bL.touches || (lv.touches == bL.touches && lv.p < bL.p))) { bL = lv; kL = k; riL = ri; }
            for (Lv lv : hp) if (k.h > lv.p && k.c < lv.p && close < lv.p && (bS == null || lv.touches > bS.touches || (lv.touches == bS.touches && lv.p > bS.p))) { bS = lv; kS = k; riS = ri; }
        }
        String side = null; Lv lv = null; C k = null; int ri = -1;
        if (bL != null && bS != null) {
            if (riL > riS) { side = "LONG"; lv = bL; k = kL; ri = riL; }
            else if (riS > riL) { side = "SHORT"; lv = bS; k = kS; ri = riS; }
        } else if (bL != null) { side = "LONG"; lv = bL; k = kL; ri = riL; }
        else if (bS != null) { side = "SHORT"; lv = bS; k = kS; ri = riS; }
        if (side == null) return null;
        boolean L = side.equals("LONG");
        List<C> after = tail(c, N - ri);
        double ext = L ? Double.MAX_VALUE : -Double.MAX_VALUE;
        for (C a : after) ext = L ? Math.min(ext, a.l) : Math.max(ext, a.h);
        Setup s = new Setup();
        s.side = side; s.stop = L ? ext - A * 0.1 : ext + A * 0.1; s.sigBar = k.t; s.sigCandle = k;
        s.bonus = lv.touches >= 2 ? 1 : 0;
        return s;
    }

    static Setup st(Ctx x) {
        List<C> c = x.c; int n = x.n; double A = x.A;
        Object[] r = superTrend(c, 10, 3);
        int[] dir = (int[]) r[0]; double lineNow = ((double[]) r[1])[n];
        for (int back = 0; back < 2; back++) {
            int i = n - back;
            if (dir[i] != 0 && dir[i - 1] != 0 && dir[i] != dir[i - 1] && dir[n] == dir[i]) {
                boolean L = dir[i] == 1; C k = c.get(i);
                double bonus = 0;
                double rng = k.h - k.l; if (rng == 0) rng = 1e-12;
                if (Math.abs(k.c - k.o) / rng >= 0.6) bonus += 0.5;
                int prevLen = 0; for (int j = i - 1; j > 0 && dir[j] == dir[i - 1]; j--) prevLen++;
                if (prevLen >= 10) bonus += 0.5;
                Setup s = new Setup();
                s.side = L ? "LONG" : "SHORT"; s.stop = L ? lineNow - A * 0.1 : lineNow + A * 0.1; s.sigBar = k.t; s.sigCandle = k; s.bonus = bonus;
                return s;
            }
        }
        return null;
    }

    static Setup smc(Ctx x) {
        List<C> c = x.c; double A = x.A;
        List<C> w = tail(c, 120); int m = w.size() - 1;
        Sw sw = findSwings(w, 3);
        if (sw.highs.size() < 2 || sw.lows.size() < 2) return null;
        P H = sw.highs.get(sw.highs.size() - 1), H0 = sw.highs.get(sw.highs.size() - 2);
        P Lw = sw.lows.get(sw.lows.size() - 1), L0 = sw.lows.get(sw.lows.size() - 2);
        for (int back = 0; back < 2; back++) {
            int i = m - back;
            if (i > H.i && w.get(i).c > H.p && w.get(i - 1).c <= H.p) {
                boolean choch = H0.p > H.p && L0.p > Lw.p;
                P prot = null; for (P p : sw.lows) if (p.i < i) prot = p;
                Setup s = new Setup(); s.side = "LONG"; s.stop = prot.p - A * 0.1; s.sigBar = w.get(i).t; s.sigCandle = w.get(i); s.bonus = choch ? 1 : 0.5;
                return s;
            }
            if (i > Lw.i && w.get(i).c < Lw.p && w.get(i - 1).c >= Lw.p) {
                boolean choch = H0.p < H.p && L0.p < Lw.p;
                P prot = null; for (P p : sw.highs) if (p.i < i) prot = p;
                Setup s = new Setup(); s.side = "SHORT"; s.stop = prot.p + A * 0.1; s.sigBar = w.get(i).t; s.sigCandle = w.get(i); s.bonus = choch ? 1 : 0.5;
                return s;
            }
        }
        return null;
    }

    static Setup ob(Ctx x) {
        List<C> c = x.c; int n = x.n; double A = x.A;
        int start = Math.max(10, c.size() - 120);
        List<double[]> obs = new ArrayList<>(); // {side(1/-1), zl, zh, i, imp}
        for (int i = n - 4; i >= start; i--) {
            C k = c.get(i);
            double up = -Double.MAX_VALUE, dn = Double.MAX_VALUE, pH = -Double.MAX_VALUE, pL = Double.MAX_VALUE;
            for (int j = i + 1; j <= i + 3; j++) { up = Math.max(up, c.get(j).c); dn = Math.min(dn, c.get(j).c); }
            for (int j = i - 8; j < i; j++) { pH = Math.max(pH, c.get(j).h); pL = Math.min(pL, c.get(j).l); }
            if (k.c < k.o && up - k.h > 0.8 * A && up > pH) obs.add(new double[]{1, k.l, k.o, i, (up - k.h) / A});
            if (k.c > k.o && k.l - dn > 0.8 * A && dn < pL) obs.add(new double[]{-1, k.o, k.h, i, (k.l - dn) / A});
        }
        C Lc = c.get(n), Pc = c.get(n - 1);
        for (double[] o : obs) {
            boolean isL = o[0] > 0; double zl = o[1], zh = o[2]; int oi = (int) o[3];
            int touches = 0; boolean dead = false;
            for (int j = oi + 4; j < n - 1; j++) {
                C k = c.get(j);
                if (isL) { if (k.c < zl) { dead = true; break; } if (k.l <= zh) touches++; }
                else { if (k.c > zh) { dead = true; break; } if (k.h >= zl) touches++; }
            }
            if (dead || touches > 1) continue;
            double mid = (zl + zh) / 2;
            boolean hitL = isL && (Lc.l <= zh || Pc.l <= zh) && Lc.c > Lc.o && Lc.c > mid;
            boolean hitS = !isL && (Lc.h >= zl || Pc.h >= zl) && Lc.c < Lc.o && Lc.c < mid;
            if (hitL || hitS) {
                Setup s = new Setup();
                s.side = hitL ? "LONG" : "SHORT";
                s.stop = hitL ? Math.min(zl, Math.min(Lc.l, Pc.l)) - A * 0.1 : Math.max(zh, Math.max(Lc.h, Pc.h)) + A * 0.1;
                s.sigBar = Lc.t; s.sigCandle = Lc; s.bonus = 0.5 + (o[4] >= 2 ? 1 : 0);
                return s;
            }
        }
        return null;
    }

    static Setup fib(Ctx x) {
        List<C> c = x.c; double A = x.A;
        List<C> w = tail(c, 150); int m = w.size() - 1;
        Sw sw = findSwings(w, 3);
        if (sw.highs.isEmpty() || sw.lows.isEmpty()) return null;
        P H = sw.highs.get(sw.highs.size() - 1), Lw = sw.lows.get(sw.lows.size() - 1);
        boolean up = H.i > Lw.i;
        P a = null;
        if (up) { for (P p : sw.lows) if (p.i < H.i) a = p; } else { for (P p : sw.highs) if (p.i < Lw.i) a = p; }
        P b = up ? H : Lw;
        if (a == null) return null;
        double range = Math.abs(b.p - a.p);
        if (range < 2 * A) return null;
        for (int i = b.i + 1; i < w.size(); i++) { C k = w.get(i); if (up ? k.c < a.p : k.c > a.p) return null; }
        double l5 = lv(up, b.p, range, 0.5), l618 = lv(up, b.p, range, 0.618), l705 = lv(up, b.p, range, 0.705), l786 = lv(up, b.p, range, 0.786), l886 = lv(up, b.p, range, 0.886);
        C Lc = w.get(m), Pc = w.get(m - 1);
        int prevTouches = 0;
        for (int i = b.i + 1; i < m - 1; i++) if (inZone(w.get(i), up, l5, l886, A)) prevTouches++;
        boolean reject = up ? (Lc.c > Lc.o && Lc.c >= l618) : (Lc.c < Lc.o && Lc.c <= l618);
        if ((inZone(Lc, up, l5, l886, A) || inZone(Pc, up, l5, l886, A)) && reject && prevTouches <= 1 && m - b.i >= 3) {
            double depth = up ? Math.min(Lc.l, Pc.l) : Math.max(Lc.h, Pc.h);
            boolean gp = up ? (depth <= l618 && depth >= l705) : (depth >= l618 && depth <= l705);
            Setup s = new Setup();
            s.side = up ? "LONG" : "SHORT";
            s.stop = up ? Math.min(depth, l786) - A * 0.1 : Math.max(depth, l786) + A * 0.1;
            s.sigBar = Lc.t; s.sigCandle = Lc; s.bonus = gp ? 1 : 0.5;
            s.fixed = new double[]{b.p, up ? b.p + range * 0.272 : b.p - range * 0.272, up ? b.p + range * 0.618 : b.p - range * 0.618};
            return s;
        }
        return null;
    }
    private static double lv(boolean up, double b, double range, double r) { return up ? b - range * r : b + range * r; }
    private static boolean inZone(C k, boolean up, double l5, double l886, double A) {
        return up ? (k.l <= l5 && k.l >= l886 - 0.2 * A) : (k.h >= l5 && k.h <= l886 + 0.2 * A);
    }

    /* ---------------- Kurulumdan işleme ---------------- */
    static Sig finalize(Ctx x, Setup s, String model) {
        double entry = x.close, A = x.A; boolean L = s.side.equals("LONG"); int dir = L ? 1 : -1;
        double stop = s.stop, risk = dir * (entry - stop), score = 0;
        if (!(risk > 0)) return null;
        if (risk < 0.5 * A) { stop = entry - dir * 0.5 * A; risk = 0.5 * A; }
        if (risk > 4 * A) score -= 1;
        double[] tp = new double[3];
        Double[] t0 = new Double[3];
        if (s.fixed != null) { for (int i = 0; i < 3; i++) t0[i] = s.fixed[i]; }
        else {
            List<Double> pools = new ArrayList<>();
            if (L) { for (Lv p : x.highPools) if (p.p > entry + risk * 0.5) pools.add(p.p); Collections.sort(pools); }
            else { for (Lv p : x.lowPools) if (p.p < entry - risk * 0.5) pools.add(p.p); pools.sort(Collections.reverseOrder()); }
            for (int i = 0; i < 3; i++) t0[i] = i < pools.size() ? pools.get(i) : null;
        }
        for (int i = 0; i < 3; i++) {
            double v = (t0[i] == null || Double.isNaN(t0[i]) || Double.isInfinite(t0[i])) ? entry + dir * risk * (i + 1) : t0[i];
            double minV = i == 0 ? entry + dir * risk * 0.5 : tp[i - 1] + dir * risk * 0.5;
            if (dir * (v - minV) < 0) v = minV;
            tp[i] = v;
        }
        double rr = dir * (tp[1] - entry) / risk;
        score += Math.min(4, rr * 1.5);
        if (x.avgVol > 0) {
            double vr = s.sigCandle.v / x.avgVol;
            if (vr >= 1.5) score += 2; else if (vr >= 1.2) score += 1;
        }
        if (!Double.isNaN(x.ema200) && (L ? entry > x.ema200 : entry < x.ema200)) score += 1.5;
        if (x.htfTrend == dir) score += 1.5; else if (x.htfTrend == -dir) score -= 1;
        score += x.volaAdj;
        score += s.bonus;
        int sc = (int) Math.max(0, Math.min(10, jsRound(score)));
        Sig g = new Sig();
        g.model = model; g.side = s.side; g.entry = entry; g.stop = stop; g.risk = risk; g.tp = tp; g.rr = rr; g.score = sc; g.sigBar = s.sigBar;
        g.strength = (sc >= 7 && rr >= 2) ? "strong" : (sc >= 4 && rr >= 1) ? "medium" : "weak";
        return g;
    }
    /** JavaScript Math.round ile aynı (0.5 yukarı yuvarlanır) */
    static double jsRound(double v) { return Math.floor(v + 0.5); }

    /** BTC'nin son 3 mumdaki hareketi (ATR cinsinden); veri yoksa NaN */
    static double btcMove(List<C> btc) {
        if (btc == null || btc.size() < 20) return Double.NaN;
        int n = btc.size() - 1; double A = atrW(btc, 14)[n];
        if (!(A > 0)) return Double.NaN;
        return (btc.get(n).c - btc.get(n - 3).c) / A;
    }

    /** Tüm modelleri çalıştırır; skor ≥ 3 olan ve BTC filtresinden geçen kurulumları döner. */
    static List<Sig> analyze(List<C> closed, List<C> htf, boolean spot) { return analyze(closed, htf, spot, Double.NaN); }
    static List<Sig> analyze(List<C> closed, List<C> htf, boolean spot, double bm) {
        List<Sig> out = new ArrayList<>();
        if (closed.size() < 60) return out;
        Ctx x = buildCtx(closed, htf);
        for (String m : MODELS) {
            Setup s;
            try {
                switch (m) {
                    case "liq": s = liq(x); break;
                    case "st": s = st(x); break;
                    case "smc": s = smc(x); break;
                    case "ob": s = ob(x); break;
                    default: s = fib(x);
                }
            } catch (Exception e) { s = null; }
            if (s == null) continue;
            if (spot && s.side.equals("SHORT")) continue;
            Sig g = finalize(x, s, m);
            if (g == null || g.score < MIN_SCORE) continue;
            if (!Double.isNaN(bm) && ((g.side.equals("LONG") && bm <= -1.5) || (g.side.equals("SHORT") && bm >= 1.5))) continue;
            out.add(g);
        }
        return out;
    }
}
