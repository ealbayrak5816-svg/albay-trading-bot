package com.albay.tradingbot;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Locale;

/** Sinyal grafiğini PNG olarak üretir (Telegram'a fotoğraf olarak gider). */
final class ChartAndroid implements ChartPlot.G {

    private final Canvas cv;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final DashPathEffect dash = new DashPathEffect(new float[]{14, 10}, 0);

    private ChartAndroid(Canvas c) { cv = c; }

    @Override public void rect(float l, float t, float r, float b, int argb) {
        p.reset(); p.setAntiAlias(true); p.setStyle(Paint.Style.FILL); p.setColor(argb);
        cv.drawRect(l, t, r, b, p);
    }
    @Override public void roundRect(float l, float t, float r, float b, float rad, int argb) {
        p.reset(); p.setAntiAlias(true); p.setStyle(Paint.Style.FILL); p.setColor(argb);
        cv.drawRoundRect(new RectF(l, t, r, b), rad, rad, p);
    }
    @Override public void line(float x1, float y1, float x2, float y2, int argb, float w, boolean d) {
        p.reset(); p.setAntiAlias(true); p.setStyle(Paint.Style.STROKE); p.setColor(argb); p.setStrokeWidth(w);
        if (d) p.setPathEffect(dash); else p.setStrokeCap(Paint.Cap.ROUND);
        cv.drawLine(x1, y1, x2, y2, p);
    }
    @Override public void text(String s, float x, float y, int argb, float size, boolean bold, int align) {
        p.reset(); p.setAntiAlias(true); p.setStyle(Paint.Style.FILL); p.setColor(argb); p.setTextSize(size);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        p.setTextAlign(align == 1 ? Paint.Align.CENTER : align == 2 ? Paint.Align.RIGHT : Paint.Align.LEFT);
        cv.drawText(s, x, y, p);
    }
    @Override public float textW(String s, float size, boolean bold) {
        p.reset(); p.setTextSize(size); p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return p.measureText(s);
    }

    /**
     * meta: {mk, sym, tf, side, entry, stop, tp:[..]}; başarısızsa null.
     * Ağ isteği yapar, ana iş parçacığında çağrılmamalı.
     */
    static byte[] render(Context c, JSONObject cfg, JSONObject meta) {
        try { return renderOrThrow(c, cfg, meta); } catch (Throwable t) { return null; }
    }
    /** Hata mesajıyla birlikte (teşhis için) */
    static byte[] renderOrThrow(Context c, JSONObject cfg, JSONObject meta) throws Exception {
        {
            String mk = meta.getString("mk"), sym = meta.getString("sym"), tf = meta.getString("tf");
            List<Engine.C> k = Scanner.fetchCandles(c, mk, sym, tf, 70);
            if (k == null || k.size() < 10) throw new Exception("mum verisi yok (" + (k == null ? 0 : k.size()) + ")");
            int from = Math.max(0, k.size() - 60);
            double[][] arr = new double[k.size() - from][];
            for (int i = from; i < k.size(); i++) { Engine.C x = k.get(i); arr[i - from] = new double[]{x.o, x.h, x.l, x.c}; }

            ChartPlot.In in = new ChartPlot.In();
            in.k = arr;
            in.side = meta.optString("side", "LONG");
            in.entry = meta.getDouble("entry");
            in.stop = meta.getDouble("stop");
            JSONArray tp = meta.optJSONArray("tp");
            in.tp = new double[tp == null ? 0 : Math.min(3, tp.length())];
            for (int i = 0; i < in.tp.length; i++) in.tp[i] = tp.optDouble(i, 0);
            in.title = pair(mk, sym) + "  ·  " + tf;
            in.sub = Scanner.mkTag(mk) + "  ·  " + new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(new java.util.Date());
            JSONObject tg = cfg == null ? null : cfg.optJSONObject("tg");
            JSONObject L = tg == null ? null : tg.optJSONObject("L");
            if (L != null) { in.entryL = L.optString("entry", in.entryL); in.stopL = L.optString("stop", in.stopL); }
            in.fmt = d -> Scanner.fmt(sym, d);
            JSONObject hit = meta.optJSONObject("hit");                    // TP/stop güncellemesi: vurulan seviyeler işaretlenir
            if (hit != null) {
                in.hitTp = Math.max(0, Math.min(3, hit.optInt("tp", 0)));
                in.hitStop = hit.optBoolean("sl", false);
                in.status = hit.optString("st", "");
                String sc = hit.optString("sc", "g");
                in.statusCol = sc.equals("r") ? ChartPlot.RED : sc.equals("y") ? ChartPlot.GOLD : ChartPlot.GREEN;
            }

            int W = 1080, H = 700;
            Bitmap bm = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
            ChartPlot.draw(new ChartAndroid(new Canvas(bm)), W, H, in);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
            bm.recycle();
            return bo.toByteArray();
        }
    }

    static String pair(String mk, String sym) {
        if (mk.equals("fx") && sym.length() >= 6) return sym.substring(0, 3) + "/" + sym.substring(3, 6);
        if (mk.equals("stock")) return Scanner.base(sym);
        return Scanner.base(sym) + "/USDT";
    }
}
