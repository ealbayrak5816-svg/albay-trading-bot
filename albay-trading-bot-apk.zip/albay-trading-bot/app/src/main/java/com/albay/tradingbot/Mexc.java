package com.albay.tradingbot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * MEXC Futures (contract v1) resmi OPEN-API istemcisi.
 * İmza: HMAC-SHA256(secret, apiKey + zaman(ms) + parametre) → hex.
 * GET: parametreler alfabetik sırayla "a=1&b=2"; POST: JSON gövdesinin kendisi.
 * Sadece resmi uç noktalar kullanılır (tarayıcı oturumu / "bypass" yok).
 */
final class Mexc {

    /** 2026'dan itibaren ana adres; eski adres yedek olarak denenir */
    static final String[] HOSTS = {"https://api.mexc.com", "https://contract.mexc.com"};

    static final class ApiError extends Exception {
        final int code;
        ApiError(int code, String msg) { super(msg); this.code = code; }
    }

    private final String key, secret;

    Mexc(String key, String secret) { this.key = key; this.secret = secret; }

    /* ---------------- Sembol ---------------- */
    /** SOLUSDT → SOL_USDT */
    static String sym(String s) {
        s = s.replace("_S", "").toUpperCase();
        if (s.contains("_")) return s;
        return s.endsWith("USDT") ? s.substring(0, s.length() - 4) + "_USDT" : s + "_USDT";
    }

    /* ---------------- Herkese açık ---------------- */
    static JSONObject contract(String mxSym) throws Exception {
        JSONObject r = request(null, null, "GET", "/api/v1/contract/detail", params("symbol", mxSym), null);
        Object d = r.opt("data");
        if (d instanceof JSONArray) {                       // bazı sürümler liste döner
            JSONArray a = (JSONArray) d;
            for (int i = 0; i < a.length(); i++) if (mxSym.equals(a.getJSONObject(i).optString("symbol"))) return a.getJSONObject(i);
            throw new ApiError(1001, "contract not found");
        }
        return (JSONObject) d;
    }
    static double lastPrice(String mxSym) throws Exception {
        JSONObject r = request(null, null, "GET", "/api/v1/contract/ticker", params("symbol", mxSym), null);
        JSONObject d = r.getJSONObject("data");
        return d.getDouble("lastPrice");
    }

    /* ---------------- Hesap ---------------- */
    /** USDT varlığı: equity, availableBalance, unrealized … */
    JSONObject usdt() throws Exception {
        JSONObject r = request(key, secret, "GET", "/api/v1/private/account/asset/USDT", new TreeMap<>(), null);
        return r.getJSONObject("data");
    }
    JSONArray openPositions(String mxSym) throws Exception {
        Map<String, String> p = new TreeMap<>();
        if (mxSym != null) p.put("symbol", mxSym);
        JSONObject r = request(key, secret, "GET", "/api/v1/private/position/open_positions", p, null);
        JSONArray a = r.optJSONArray("data");
        return a != null ? a : new JSONArray();
    }
    int positionMode() throws Exception {
        return request(key, secret, "GET", "/api/v1/private/position/position_mode", new TreeMap<>(), null).optInt("data", 0);
    }

    /* ---------------- Emir ---------------- */
    /**
     * Piyasa emri (type 5), izole marj (openType 1).
     * side: 1 long aç, 2 short kapat, 3 short aç, 4 long kapat.
     */
    String submit(String mxSym, int side, double vol, double price, int lev, Double stopLoss, Long positionId, String extId) throws Exception {
        JSONObject b = new JSONObject();
        b.put("symbol", mxSym);
        b.put("price", price);
        b.put("vol", vol);
        b.put("side", side);
        b.put("type", 5);
        b.put("openType", 1);
        if (lev > 0) b.put("leverage", lev);
        if (stopLoss != null) b.put("stopLossPrice", stopLoss);
        if (positionId != null) b.put("positionId", positionId);
        if (extId != null) b.put("externalOid", extId);
        JSONObject r = request(key, secret, "POST", "/api/v1/private/order/submit", null, b.toString());
        return String.valueOf(r.opt("data"));
    }
    /** Sadece kapatan limit emri (TP): side 4 long kapat / 2 short kapat, type 1 limit, pozisyona bağlı */
    String closeLimit(String mxSym, int side, double vol, double price, long positionId, String extId) throws Exception {
        JSONObject b = new JSONObject();
        b.put("symbol", mxSym);
        b.put("price", price);
        b.put("vol", vol);
        b.put("side", side);
        b.put("type", 1);
        b.put("openType", 1);
        b.put("positionId", positionId);
        if (extId != null) b.put("externalOid", extId);
        JSONObject r = request(key, secret, "POST", "/api/v1/private/order/submit", null, b.toString());
        return String.valueOf(r.opt("data"));
    }
    /** Belirli emirleri iptal eder (en fazla 50) */
    void cancel(JSONArray orderIds) throws Exception {
        if (orderIds == null || orderIds.length() == 0) return;
        request(key, secret, "POST", "/api/v1/private/order/cancel", null, orderIds.toString());
    }
    void cancelAll(String mxSym) throws Exception {
        JSONObject b = new JSONObject();
        if (mxSym != null) b.put("symbol", mxSym);
        request(key, secret, "POST", "/api/v1/private/order/cancel_all", null, b.toString());
    }
    /** Pozisyona bağlı açık TP/SL emirleri */
    JSONArray stopOrders(String mxSym) throws Exception {
        Map<String, String> p = params("symbol", mxSym);
        p.put("is_finished", "0"); p.put("page_num", "1"); p.put("page_size", "50");
        JSONObject r = request(key, secret, "GET", "/api/v1/private/stoporder/list/orders", p, null);
        JSONArray a = r.optJSONArray("data");
        return a != null ? a : new JSONArray();
    }
    void changeStop(long stopOrderId, double stopLoss) throws Exception {
        JSONObject b = new JSONObject();
        b.put("orderId", stopOrderId);
        b.put("stopLossPrice", stopLoss);
        request(key, secret, "POST", "/api/v1/private/stoporder/change_price", null, b.toString());
    }
    void stopCancelAll(String mxSym) throws Exception {
        JSONObject b = new JSONObject();
        if (mxSym != null) b.put("symbol", mxSym);
        request(key, secret, "POST", "/api/v1/private/stoporder/cancel_all", null, b.toString());
    }

    /* ---------------- HTTP + imza ---------------- */
    static Map<String, String> params(String... kv) {
        Map<String, String> m = new TreeMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }
    static String hmacHex(String secret, String msg) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] h = mac.doFinal(msg.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder(h.length * 2);
        for (byte x : h) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }
    private static String query(Map<String, String> p) throws Exception {
        StringBuilder sb = new StringBuilder();
        if (p != null) for (Map.Entry<String, String> e : p.entrySet()) {   // TreeMap: alfabetik sıra
            if (e.getValue() == null) continue;
            if (sb.length() > 0) sb.append('&');
            sb.append(e.getKey()).append('=').append(URLEncoder.encode(e.getValue(), "UTF-8"));
        }
        return sb.toString();
    }

    /** Son çalışan adres. POST (emir) asla "belki gitti" hatasında başka adrese tekrar gönderilmez: çift emir riski. */
    private static volatile String host = HOSTS[0];

    private static JSONObject request(String key, String secret, String method, String path, Map<String, String> p, String body) throws Exception {
        String first = host;
        try { return once(key, secret, first, method, path, p, body); }
        catch (IOException e) {
            String m = String.valueOf(e.getMessage());
            boolean notSent = m.startsWith("HTTP 404");                 // sunucu bu yolu tanımadı: işlenmedi
            boolean retryOk = "GET".equals(method) ? (notSent || m.startsWith("NET")) : notSent;
            if (!retryOk) throw e;
            String other = first.equals(HOSTS[0]) ? HOSTS[1] : HOSTS[0];
            JSONObject r = once(key, secret, other, method, path, p, body);
            host = other;
            return r;
        }
    }

    private static JSONObject once(String key, String secret, String host, String method, String path, Map<String, String> p, String body) throws Exception {
        String q = query(p);
        String url = host + path + (q.isEmpty() ? "" : "?" + q);
        HttpURLConnection c;
        try { c = (HttpURLConnection) new URL(url).openConnection(); }
        catch (IOException e) { throw new IOException("NET " + e.getMessage()); }
        c.setConnectTimeout(10_000); c.setReadTimeout(15_000);
        c.setRequestMethod(method);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Accept", "application/json");
        if (key != null) {
            String ts = String.valueOf(System.currentTimeMillis());
            String param = "POST".equals(method) ? (body == null ? "" : body) : q;
            c.setRequestProperty("ApiKey", key);
            c.setRequestProperty("Request-Time", ts);
            c.setRequestProperty("Recv-Window", "15");
            c.setRequestProperty("Signature", hmacHex(secret, key + ts + param));
        }
        try {
            if ("POST".equals(method)) {
                c.setDoOutput(true);
                byte[] b = (body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8);
                try (OutputStream o = c.getOutputStream()) { o.write(b); }
            }
            int code;
            try { code = c.getResponseCode(); }
            catch (IOException e) { throw new IOException("NET " + e.getMessage()); }
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String txt = "";
            if (in != null) try (InputStream i2 = in) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = i2.read(buf)) > 0) bo.write(buf, 0, n);
                txt = new String(bo.toByteArray(), StandardCharsets.UTF_8);
            }
            if (code == 404) throw new IOException("HTTP 404");
            JSONObject r;
            try { r = new JSONObject(txt); }
            catch (Exception e) { throw new IOException("HTTP " + code + " " + txt.substring(0, Math.min(120, txt.length()))); }
            if (!r.optBoolean("success", false)) {
                int ec = r.optInt("code", code);
                String msg = r.optString("message", r.optString("msg", "HTTP " + code));
                throw new ApiError(ec, ec + " " + msg);
            }
            return r;
        } finally { c.disconnect(); }
    }
}
