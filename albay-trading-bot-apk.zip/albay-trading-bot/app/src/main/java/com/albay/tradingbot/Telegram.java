package com.albay.tradingbot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashSet;

/**
 * Bot sinyallerini Telegram grubuna/kanalına gönderir.
 * Uygulama ve arka plan motoru aynı anahtarı kullanır; aynı olay gruba asla iki kez gitmez.
 */
final class Telegram {

    private static final String PREF = "albay_tg";
    private static final int MAX = 1500;
    private static LinkedHashSet<String> sent;

    private static synchronized void load(Context c) {
        if (sent != null) return;
        sent = new LinkedHashSet<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("sent", "[]"));
            for (int i = 0; i < a.length(); i++) sent.add(a.getString(i));
        } catch (Exception ignored) { }
    }
    private static void persist(Context c) {
        Iterator<String> it = sent.iterator();
        while (sent.size() > MAX && it.hasNext()) { it.next(); it.remove(); }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("sent", new JSONArray(sent).toString()).apply();
    }
    /** Anahtar daha önce gönderilmediyse işaretler ve true döner */
    private static synchronized boolean claim(Context c, String key) { load(c); if (!sent.add(key)) return false; persist(c); return true; }
    private static synchronized void release(Context c, String key) { load(c); if (sent.remove(key)) persist(c); }

    static String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    /**
     * Ayarlara göre gönderilip gönderilmeyeceğine karar verir.
     * ev: "new" (yeni sinyal), "tp" (TP1/TP2/runner), "close" (stop, TP3, runner çıkışı, süre doldu)
     */
    static void maybe(Context c, JSONObject cfg, String mk, String ev, boolean strong, String key, String html) {
        JSONObject tg = cfg == null ? null : cfg.optJSONObject("tg");
        if (tg == null || !tg.optBoolean("on", false)) return;
        String token = tg.optString("token", "").trim(), chat = tg.optString("chat", "").trim();
        if (token.isEmpty() || chat.isEmpty() || key == null || key.isEmpty()) return;
        JSONObject mks = tg.optJSONObject("mk");
        if (mks != null && !mks.optBoolean(mk, true)) return;
        if (ev.equals("new") && tg.optBoolean("strong", false) && !strong) return;
        if (ev.equals("tp") && !tg.optBoolean("tp", true)) return;
        if (ev.equals("close") && !tg.optBoolean("close", true)) return;
        final String k = "tg|" + key;
        String disc = tg.optString("disc", "");
        if (html == null || html.isEmpty()) return;
        final String text = html + (disc.isEmpty() ? "" : "\n\n<i>" + esc(disc) + "</i>");
        if (!claim(c, k)) return;
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try { send(token, chat, text); }
            catch (Exception e) { release(app, k); }                 // başarısızsa tekrar denenebilsin
        }).start();
    }

    /** Senkron gönderim (test butonu); Telegram'ın JSON cevabını döner */
    static String send(String token, String chat, String html) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/sendMessage").openConnection();
        c.setConnectTimeout(10_000); c.setReadTimeout(15_000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        String form = "chat_id=" + URLEncoder.encode(chat, "UTF-8")
            + "&parse_mode=HTML&disable_web_page_preview=true&text=" + URLEncoder.encode(html, "UTF-8");
        try (OutputStream os = c.getOutputStream()) { os.write(form.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String res = "";
        if (in != null) {
            try (InputStream is = in) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                res = new String(bo.toByteArray(), StandardCharsets.UTF_8);
            }
        }
        c.disconnect();
        if (code != 200) throw new Exception(res.isEmpty() ? "HTTP " + code : res);
        return res;
    }

    /** Uygulamadaki test ve "grup kimliğini bul" butonları için basit GET */
    static String call(String token, String method) {
        try { return Scanner.get("https://api.telegram.org/bot" + token + "/" + method); }
        catch (Exception e) { return "{\"ok\":false,\"description\":\"" + esc(String.valueOf(e.getMessage())).replace("\"", "'") + "\"}"; }
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
}
