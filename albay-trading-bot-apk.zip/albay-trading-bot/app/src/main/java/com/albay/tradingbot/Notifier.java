package com.albay.tradingbot;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;

import java.util.Iterator;
import java.util.LinkedHashSet;

/**
 * Tek bildirim noktası: uygulama ve arka plan motoru aynı anahtarı kullandığı için
 * aynı olay asla iki kez bildirilmez.
 */
final class Notifier {

    private static final String PREF = "albay_notif";
    private static final int MAX = 1500;
    private static LinkedHashSet<String> seen, notified;
    private static int nextId = 2000;

    private static synchronized void load(Context c) {
        if (seen != null) return;
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        seen = read(sp.getString("seen", "[]"));
        notified = read(sp.getString("notified", "[]"));
    }
    private static LinkedHashSet<String> read(String json) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(json); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); } catch (Exception ignored) { }
        return s;
    }
    private static void persist(Context c) {
        trim(seen); trim(notified);
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("seen", new JSONArray(seen).toString())
            .putString("notified", new JSONArray(notified).toString()).apply();
    }
    private static void trim(LinkedHashSet<String> s) {
        Iterator<String> it = s.iterator();
        while (s.size() > MAX && it.hasNext()) { it.next(); it.remove(); }
    }

    static synchronized boolean seen(Context c, String key) { load(c); return seen.contains(key) || notified.contains(key); }
    static synchronized void markSeen(Context c, String key) { load(c); if (seen.add(key)) persist(c); }
    static synchronized boolean wasNotified(Context c, String key) { load(c); return notified.contains(key); }

    static synchronized void notifyOnce(Context c, String key, String title, String body) {
        load(c);
        if (key != null && !key.isEmpty()) {
            if (notified.contains(key)) return;
            notified.add(key); seen.add(key); persist(c);
        }
        post(c, title, body);
    }

    static void post(Context c, String title, String body) {
        NativeBridge.createChannels(c);
        if (!NotificationManagerCompat.from(c).areNotificationsEnabled()) return;
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, NativeBridge.CH_SIGNALS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(NativeBridge.openApp(c));
        try { NotificationManagerCompat.from(c).notify(nextId++, b.build()); } catch (SecurityException ignored) { }
    }
}
