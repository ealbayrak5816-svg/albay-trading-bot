package com.albay.tradingbot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Uygulama kapalıyken çalışan tarayıcı.
 * Her mum kapanışında: veriyi çeker → 5 modeli çalıştırır → yeni sinyalleri bildirir →
 * açık sinyal/işlemlerin TP, runner ve stop olaylarını kontrol eder.
 */
final class Scanner {

    static final String PREF = "albay_engine";
    static final Map<String, Long> TF_MS = new HashMap<>();
    static final Map<String, String> HTF = new HashMap<>();
    static {
        TF_MS.put("1m", 60_000L); TF_MS.put("5m", 300_000L); TF_MS.put("15m", 900_000L); TF_MS.put("1h", 3_600_000L);
        TF_MS.put("4h", 14_400_000L); TF_MS.put("1d", 86_400_000L); TF_MS.put("1w", 604_800_000L);
        HTF.put("1m", "15m"); HTF.put("5m", "1h"); HTF.put("15m", "1h"); HTF.put("1h", "4h"); HTF.put("4h", "1d"); HTF.put("1d", "1w");
    }
    static final String[] DEFAULT_TFS = {"5m", "15m", "1h", "4h", "1d"};

    private final Context ctx;
    private final SharedPreferences sp;
    private final Map<String, List<Engine.C>> cache = new HashMap<>();

    Scanner(Context c) { ctx = c.getApplicationContext(); sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    /* ---------------- Yapılandırma ---------------- */
    static JSONObject config(Context c) {
        try { return new JSONObject(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("cfg", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    static List<String> tfs(JSONObject cfg) {
        List<String> out = new ArrayList<>();
        JSONArray a = cfg.optJSONArray("tfs");
        if (a != null) for (int i = 0; i < a.length(); i++) { String tf = a.optString(i); if (TF_MS.containsKey(tf) && !tf.equals("1m")) out.add(tf); }
        if (out.isEmpty()) for (String tf : DEFAULT_TFS) out.add(tf);
        return out;
    }

    /* ---------------- Ana tarama ---------------- */
    private int nReq = 0, nFound = 0, nSent = 0, nEv = 0, nBlocked = 0;

    void runScan() { runScan(false); }
    void runScan(boolean force) {
        long now = System.currentTimeMillis();
        JSONObject cfg = config(ctx);
        List<String> all = tfs(cfg);
        JSONArray pos = positions();
        // Açık pozisyonların zaman dilimleri de taranır
        for (int i = 0; i < pos.length(); i++) { String tf = pos.optJSONObject(i).optString("tf"); if (TF_MS.containsKey(tf) && !all.contains(tf)) all.add(tf); }

        List<String> due = new ArrayList<>();
        SharedPreferences.Editor ed = sp.edit();
        for (String tf : all) {
            long ms = TF_MS.get(tf), bar = (now / ms) * ms;
            if (force || bar > sp.getLong("bar_" + tf, 0)) { due.add(tf); ed.putLong("bar_" + tf, bar); }
        }
        ed.apply();
        if (due.isEmpty()) { status(null, due, force); return; }

        String err = null;
        JSONObject markets = cfg.optJSONObject("markets");
        String[] mks = {"crypto", "spot", "fx", "stock"};
        Set<String> active = new HashSet<>();
        for (int i = 0; i < pos.length(); i++) { JSONObject p = pos.optJSONObject(i); if ("sig".equals(p.optString("kind"))) active.add(p.optString("market") + "|" + p.optString("key")); }

        loadCalendar();
        for (String mk : mks) {
            List<String> syms = new ArrayList<>();
            JSONArray w = markets != null ? markets.optJSONArray(mk) : null;
            if (w != null) for (int i = 0; i < w.length(); i++) syms.add(w.optString(i));
            for (int i = 0; i < pos.length(); i++) { JSONObject p = pos.optJSONObject(i); if (mk.equals(p.optString("market")) && !syms.contains(p.optString("sym"))) syms.add(p.optString("sym")); }
            for (String sym : syms) for (String tf : due) {
                try {
                    if (mk.equals("stock") && !stockOpen(sym) && !force) continue;     // seans kapalı: yeni mum yok
                    List<Engine.C> k = candles(mk, sym, tf, 300);
                    nReq++;
                    if (k.size() < 3) continue;
                    List<Engine.C> closed = closedOf(mk, k, tf);
                    if (w != null && contains(w, sym)) {
                        List<Engine.C> h = null;
                        try { List<Engine.C> hk = candles(mk, sym, HTF.get(tf), 80); h = closedOf(mk, hk, HTF.get(tf)); } catch (Exception ignored) { }
                        double bm = Double.NaN;
                        if (!mk.equals("fx") && !sym.replace("_S", "").equals("BTCUSDT")) {
                            try { List<Engine.C> b = candles("crypto", "BTCUSDT", tf, 300); bm = Engine.btcMove(b.subList(0, b.size() - 1)); } catch (Exception ignored) { }
                        }
                        scanSignals(cfg, mk, sym, tf, closed, h, active, bm);
                    }
                    checkPositions(cfg, pos, mk, sym, tf, closed);
                } catch (Exception e) { err = mk + " " + sym + " " + tf + ": " + e.getMessage(); }
            }
        }
        savePositions(pos);
        status(err, due, force);
    }

    private static boolean contains(JSONArray a, String s) { for (int i = 0; i < a.length(); i++) if (s.equals(a.optString(i))) return true; return false; }

    /** Tarama sonucu ve son 30 taramanın günlüğü (teşhis paneli için) */
    private void status(String err, List<String> due, boolean force) {
        long now = System.currentTimeMillis();
        SharedPreferences.Editor e = sp.edit().putLong("lastScan", now).putInt("scans", sp.getInt("scans", 0) + 1);
        if (err != null) e.putString("lastError", err); else e.remove("lastError");
        try {
            JSONArray log = new JSONArray(sp.getString("log", "[]"));
            JSONObject o = new JSONObject();
            o.put("t", now); o.put("due", new JSONArray(due)); o.put("req", nReq); o.put("found", nFound); o.put("sent", nSent);
            o.put("ev", nEv); o.put("blocked", nBlocked); o.put("force", force); if (err != null) o.put("err", err);
            JSONArray out = new JSONArray(); out.put(o);
            for (int i = 0; i < log.length() && i < 29; i++) out.put(log.get(i));
            e.putString("log", out.toString());
        } catch (Exception ignored) { }
        e.apply();
    }

    /* ---------------- Yeni sinyaller ---------------- */
    private void scanSignals(JSONObject cfg, String mk, String sym, String tf, List<Engine.C> closed, List<Engine.C> htf, Set<String> active, double bm) {
        long ms = TF_MS.get(tf), barTime = closed.get(closed.size() - 1).t;
        if (newsBlocked(cfg, sym)) { nBlocked++; return; }          // önemli veri öncesi/sonrası yeni sinyal yok
        for (Engine.Sig s : Engine.analyze(closed, htf, mk.equals("spot") || mk.equals("stock"), bm)) {
            nFound++;
            String key = sym + "|" + tf + "|" + s.model;
            if (active.contains(mk + "|" + key)) continue;             // aynı model/zaman diliminde açık sinyal var
            if (s.sigBar < barTime - 2 * ms) continue;                 // eski kurulum
            String nKey = mk + "|" + sym + "|" + tf + "|" + s.model + "|" + s.sigBar;
            if (Notifier.seen(ctx, nKey)) continue;
            Notifier.markSeen(ctx, nKey);
            boolean strong = s.strength.equals("strong");
            if (!cfg.optBoolean("notify", true) || !(strong || cfg.optBoolean("notifyAll", false))) continue;
            Txt T = new Txt(cfg);
            String title = T.f("newSig", "dot", s.side.equals("LONG") ? "🟢" : "🔴", "mk", mkTag(mk), "c", base(sym), "tf", tf, "m", T.model(s.model), "side", s.side, "st", T.s("st." + s.strength));
            String body = T.f("newB", "e", fmt(sym, s.entry), "s", fmt(sym, s.stop), "rr", String.format(Locale.US, "%.2f", s.rr));
            Notifier.notifyOnce(ctx, nKey, title, body);
            nSent++;
        }
    }

    /* ---------------- Açık sinyal ve işlemler ---------------- */
    private void checkPositions(JSONObject cfg, JSONArray pos, String mk, String sym, String tf, List<Engine.C> closed) throws Exception {
        for (int i = 0; i < pos.length(); i++) {
            JSONObject p = pos.getJSONObject(i);
            if (!mk.equals(p.optString("market")) || !sym.equals(p.optString("sym")) || !tf.equals(p.optString("tf")) || p.optBoolean("closed")) continue;
            boolean L = "LONG".equals(p.optString("side"));
            JSONArray tpA = p.getJSONArray("tp");
            double entry = p.getDouble("entry"), stop = p.getDouble("stop");
            double[] tp = {tpA.getDouble(0), tpA.getDouble(1), tpA.getDouble(2)};
            long from = p.optLong("from", 0), checked = p.optLong("checked", 0);
            for (int j = 0; j < closed.size(); j++) {
                Engine.C k = closed.get(j);
                if (k.t < from || k.t <= checked) continue;
                p.put("checked", k.t);
                // Stop önce kontrol edilir (muhafazakâr)
                if (L ? k.l <= stop : k.h >= stop) {
                    String type = p.optBoolean("runner") ? "RUN" : !p.optBoolean("tp1Hit") ? "SL" : !p.optBoolean("tp2Hit") ? "BE" : "TP1SL";
                    event(cfg, p, type, stop); p.put("closed", true); break;
                }
                if (!p.optBoolean("tp1Hit") && (L ? k.h >= tp[0] : k.l <= tp[0])) { p.put("tp1Hit", true); stop = entry; p.put("stop", stop); event(cfg, p, "TP1", tp[0]); }
                if (p.optBoolean("tp1Hit") && !p.optBoolean("tp2Hit") && (L ? k.h >= tp[1] : k.l <= tp[1])) { p.put("tp2Hit", true); stop = tp[0]; p.put("stop", stop); event(cfg, p, "TP2", tp[1]); }
                if (p.optBoolean("tp2Hit") && !p.optBoolean("tp3Hit") && (L ? k.h >= tp[2] : k.l <= tp[2])) {
                    Engine.Mo mo = Engine.momentum(closed.subList(0, j + 1), L);
                    if (mo.ok) { p.put("tp3Hit", true); p.put("runner", true); stop = tp[1]; p.put("stop", stop); p.put("runnerFrom", k.t); event(cfg, p, "RUNON", tp[2]); }
                    else { event(cfg, p, "TP3", tp[2]); p.put("closed", true); break; }
                } else if (p.optBoolean("runner") && k.t > p.optLong("runnerFrom", 0)) {
                    double[] rc = Engine.runnerCheck(L, stop, closed.subList(0, j + 1));
                    if (rc != null) {
                        if (rc[0] > 0) { event(cfg, p, "RUN", rc[2]); p.put("closed", true); break; }
                        stop = rc[1]; p.put("stop", stop);
                    }
                }
            }
        }
    }

    private void event(JSONObject cfg, JSONObject p, String ev, double price) {
        if (!cfg.optBoolean("notify", true)) return;
        Txt T = new Txt(cfg);
        boolean trade = "trade".equals(p.optString("kind"));
        String mk = p.optString("market"), sym = p.optString("sym"), tf = p.optString("tf"), side = p.optString("side");
        String c = base(sym), m = T.model(p.optString("model"));
        String title, body;
        switch (ev) {
            case "TP1": case "TP2":
                title = trade ? T.f("tradeTp", "mk", mkTag(mk), "c", c, "tp", ev) : T.f("tp", "mk", mkTag(mk), "c", c, "tf", tf, "m", m, "tp", ev);
                body = T.s(ev.equals("TP1") ? "tp1B" : "tp2B");
                break;
            case "RUNON":
                title = trade ? T.f("tradeRunner", "mk", mkTag(mk), "c", c) : T.f("runner", "mk", mkTag(mk), "c", c, "tf", tf, "m", m);
                body = T.s("runnerB");
                break;
            default:
                String icon = ev.equals("SL") ? "🛑" : ev.equals("BE") || ev.equals("TP1SL") ? "🛡️" : ev.equals("TP3") ? "✅" : "🏁";
                title = trade ? T.f("tradeClosed", "icon", icon, "mk", mkTag(mk), "c", c, "side", side, "type", T.s("type." + ev))
                              : T.f("closed", "icon", icon, "mk", mkTag(mk), "c", c, "tf", tf, "m", m, "side", side, "type", T.s("type." + ev));
                body = T.f("priceB", "p", fmt(sym, price));
        }
        Notifier.notifyOnce(ctx, p.optString("pid") + "|" + ev, title, body);
        nEv++;
    }

    /** Kapanmış mumu olan (kapanıştan 8 sn geçmiş) ve henüz taranmamış zaman dilimi var mı? */
    static boolean dueAny(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        for (String tf : tfs(config(c))) {
            long ms = TF_MS.get(tf), bar = (now / ms) * ms;
            if (now - bar >= 8_000L && bar > sp.getLong("bar_" + tf, 0)) return true;
        }
        return false;
    }

    /* ---------------- Sürekli canlı mod: anlık fiyatla TP / stop takibi ---------------- */
    void checkPrices() {
        JSONArray pos = positions();
        if (pos.length() == 0) return;
        JSONObject cfg = config(ctx);
        Map<String, Double> px = new HashMap<>();
        boolean needF = false, needS = false; List<String> fx = new ArrayList<>();
        for (int i = 0; i < pos.length(); i++) {
            JSONObject p = pos.optJSONObject(i); if (p == null) continue;
            String mk = p.optString("market"), sym = p.optString("sym");
            if (mk.equals("crypto") || sym.equals("XAUUSD") || sym.equals("XAGUSD")) needF = true;
            else if (mk.equals("spot")) needS = true;
            else if (mk.equals("fx")) fx.add(sym);
            else if (mk.equals("stock") && stockOpen(sym)) { try { px.put("stock|" + sym, yahooPrice(sym)); } catch (Exception ignored) { } }
        }
        try {
            if (needF) { JSONArray a = new JSONArray(get("https://fapi.binance.com/fapi/v1/ticker/price")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); px.put("crypto|" + o.getString("symbol"), o.getDouble("price")); } }
            if (needS) { JSONArray a = new JSONArray(get("https://api.binance.com/api/v3/ticker/price")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); px.put("spot|" + o.getString("symbol") + "_S", o.getDouble("price")); } }
            if (!fx.isEmpty()) {
                StringBuilder pairs = new StringBuilder();
                for (String s : fx) if (!s.startsWith("XA")) { if (pairs.length() > 0) pairs.append(','); pairs.append(s); }
                if (pairs.length() > 0) {
                    JSONObject r = new JSONObject(get("https://api.kraken.com/0/public/Ticker?pair=" + pairs)).getJSONObject("result");
                    for (Iterator<String> it = r.keys(); it.hasNext(); ) {
                        String k = it.next(); JSONObject o = r.getJSONObject(k);
                        double bid = o.getJSONArray("b").getDouble(0), ask = o.getJSONArray("a").getDouble(0);
                        String norm = k.replace("Z", "").replace("X", "");      // ZEURZUSD → EURUSD
                        for (String s : fx) if (norm.equals(s) || k.equals(s)) px.put("fx|" + s, (bid + ask) / 2);
                    }
                }
            }
        } catch (Exception e) { return; }
        boolean changed = false;
        for (int i = 0; i < pos.length(); i++) {
            JSONObject p = pos.optJSONObject(i); if (p == null || p.optBoolean("closed")) continue;
            String mk = p.optString("market"), sym = p.optString("sym");
            String key = (sym.equals("XAUUSD") ? "crypto|XAUUSDT" : sym.equals("XAGUSD") ? "crypto|XAGUSDT" : mk + "|" + sym);
            Double price = px.get(key);
            if (price == null) continue;
            try { if (stepLive(cfg, p, price)) changed = true; } catch (Exception ignored) { }
        }
        if (changed) savePositions(pos);
    }
    /** Anlık fiyatla tek adım; durum değiştiyse true */
    private boolean stepLive(JSONObject cfg, JSONObject p, double price) throws Exception {
        boolean L = "LONG".equals(p.optString("side"));
        JSONArray tpA = p.getJSONArray("tp");
        double entry = p.getDouble("entry"), stop = p.getDouble("stop");
        double[] tp = {tpA.getDouble(0), tpA.getDouble(1), tpA.getDouble(2)};
        if (L ? price <= stop : price >= stop) {
            String type = p.optBoolean("runner") ? "RUN" : !p.optBoolean("tp1Hit") ? "SL" : !p.optBoolean("tp2Hit") ? "BE" : "TP1SL";
            event(cfg, p, type, stop); p.put("closed", true); return true;
        }
        boolean ch = false;
        if (!p.optBoolean("tp1Hit") && (L ? price >= tp[0] : price <= tp[0])) { p.put("tp1Hit", true); p.put("stop", entry); event(cfg, p, "TP1", tp[0]); ch = true; }
        if (p.optBoolean("tp1Hit") && !p.optBoolean("tp2Hit") && (L ? price >= tp[1] : price <= tp[1])) { p.put("tp2Hit", true); p.put("stop", tp[0]); event(cfg, p, "TP2", tp[1]); ch = true; }
        if (p.optBoolean("tp2Hit") && !p.optBoolean("tp3Hit") && (L ? price >= tp[2] : price <= tp[2])) {
            List<Engine.C> k = candles(p.optString("market"), p.optString("sym"), p.optString("tf"), 300);
            Engine.Mo mo = Engine.momentum(k.subList(0, k.size() - 1), L);
            if (mo.ok) { p.put("tp3Hit", true); p.put("runner", true); p.put("stop", tp[1]); p.put("runnerFrom", k.get(k.size() - 2).t); event(cfg, p, "RUNON", tp[2]); }
            else { event(cfg, p, "TP3", tp[2]); p.put("closed", true); }
            ch = true;
        }
        return ch;
    }

    /* ---------------- Ekonomik takvim (haber filtresi) ---------------- */
    private JSONArray calendar = new JSONArray();
    private void loadCalendar() {
        try {
            long t = sp.getLong("calT", 0);
            if (System.currentTimeMillis() - t > 3 * 3_600_000L) {
                String s = get("https://nfs.faireconomy.media/ff_calendar_thisweek.json");
                sp.edit().putString("cal", s).putLong("calT", System.currentTimeMillis()).apply();
            }
            calendar = new JSONArray(sp.getString("cal", "[]"));
        } catch (Exception e) {
            try { calendar = new JSONArray(sp.getString("cal", "[]")); } catch (Exception ignored) { }
        }
    }
    private boolean newsBlocked(JSONObject cfg, String sym) {
        if (!cfg.optBoolean("newsFilter", true)) return false;
        long win = cfg.optLong("newsWin", 30) * 60_000L, now = System.currentTimeMillis();
        Set<String> cur = new HashSet<>();
        if (isStock(sym)) cur.add(sym.endsWith(".DE") ? "EUR" : sym.endsWith(".IS") ? "TRY" : "USD");
        else if (isFx(sym)) { String b = sym.substring(0, 3), q = sym.substring(3); cur.add(b.equals("XAU") || b.equals("XAG") ? "USD" : b); cur.add(q); }
        else cur.add("USD");
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US);
        for (int i = 0; i < calendar.length(); i++) {
            JSONObject e = calendar.optJSONObject(i);
            if (e == null || !"High".equals(e.optString("impact")) || !cur.contains(e.optString("country"))) continue;
            try { long t = f.parse(e.optString("date")).getTime(); if (now >= t - win && now <= t + win) return true; } catch (Exception ignored) { }
        }
        return false;
    }

    /* ---------------- Pozisyon listesi ---------------- */
    JSONArray positions() {
        try { return new JSONArray(sp.getString("pos", "[]")); } catch (Exception e) { return new JSONArray(); }
    }
    private void savePositions(JSONArray pos) {
        JSONArray keep = new JSONArray();
        for (int i = 0; i < pos.length(); i++) { JSONObject p = pos.optJSONObject(i); if (p != null && !p.optBoolean("closed")) keep.put(p); }
        sp.edit().putString("pos", keep.toString()).apply();
    }
    /** Uygulamadan gelen güncel liste; arka planda ilerlemiş durumlar (TP1, runner…) korunur. */
    static void mergePositions(Context c, String json) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray in = new JSONArray(json), old = new JSONArray(sp.getString("pos", "[]"));
            Map<String, JSONObject> prev = new HashMap<>();
            for (int i = 0; i < old.length(); i++) prev.put(old.getJSONObject(i).optString("pid"), old.getJSONObject(i));
            for (int i = 0; i < in.length(); i++) {
                JSONObject p = in.getJSONObject(i), o = prev.get(p.optString("pid"));
                if (o != null) p.put("checked", Math.max(p.optLong("checked", 0), o.optLong("checked", 0)));
            }
            sp.edit().putString("pos", in.toString()).apply();
        } catch (Exception ignored) { }
    }

    /* ---------------- Veri ---------------- */
    private List<Engine.C> candles(String mk, String sym, String tf, int limit) throws Exception {
        String ck = mk + "|" + sym + "|" + tf + "|" + limit;
        List<Engine.C> hit = cache.get(ck);
        if (hit != null) return hit;
        List<Engine.C> out;
        if (mk.equals("stock")) out = yahoo(sym, tf, limit);
        else if (mk.equals("crypto")) out = binance("https://fapi.binance.com/fapi/v1/klines?symbol=" + sym + "&interval=" + tf + "&limit=" + limit);
        else if (mk.equals("spot")) out = binance("https://api.binance.com/api/v3/klines?symbol=" + sym.replace("_S", "") + "&interval=" + tf + "&limit=" + limit);
        else {
            String bnf = sym.equals("XAUUSD") ? "XAUUSDT" : sym.equals("XAGUSD") ? "XAGUSDT" : null;
            out = null;
            if (bnf != null) { try { out = binance("https://fapi.binance.com/fapi/v1/klines?symbol=" + bnf + "&interval=" + tf + "&limit=" + limit); } catch (Exception ignored) { } }
            if (out == null) out = kraken(sym.equals("XAUUSD") ? "PAXGUSD" : sym, tf, limit);
        }
        cache.put(ck, out);
        return out;
    }
    private static List<Engine.C> binance(String url) throws Exception {
        JSONArray a = new JSONArray(get(url));
        List<Engine.C> out = new ArrayList<>(a.length());
        for (int i = 0; i < a.length(); i++) {
            JSONArray k = a.getJSONArray(i);
            out.add(new Engine.C(k.getLong(0), k.getDouble(1), k.getDouble(2), k.getDouble(3), k.getDouble(4), k.getDouble(5)));
        }
        return out;
    }
    /* ---------------- Hisse (Yahoo Finance) ---------------- */
    static boolean isStock(String s) { return s.startsWith("STK:"); }
    /** Kapanmış mumlar: kripto/forex’te son mum açık; hissede zamana göre belirlenir */
    static List<Engine.C> closedOf(String mk, List<Engine.C> k, String tf) {
        if (!mk.equals("stock")) return k.subList(0, k.size() - 1);
        long ms = TF_MS.get(tf), now = System.currentTimeMillis();
        List<Engine.C> out = new ArrayList<>();
        for (Engine.C c : k) if (c.t + ms <= now) out.add(c);
        return out;
    }
    static boolean stockOpen(String sym) {
        String tz = sym.endsWith(".DE") ? "Europe/Berlin" : sym.endsWith(".IS") ? "Europe/Istanbul" : "America/New_York";
        int o = sym.endsWith(".DE") ? 9 * 60 : sym.endsWith(".IS") ? 10 * 60 : 9 * 60 + 30;
        int cl = sym.endsWith(".DE") ? 17 * 60 + 30 : sym.endsWith(".IS") ? 18 * 60 : 16 * 60;
        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone(tz));
        int wd = cal.get(java.util.Calendar.DAY_OF_WEEK), m = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE);
        return wd != java.util.Calendar.SATURDAY && wd != java.util.Calendar.SUNDAY && m >= o && m < cl;
    }
    private static JSONObject yahooRaw(String sym, String iv, String range) throws Exception {
        String y = sym.replace("STK:", "");
        String url = "https://query1.finance.yahoo.com/v8/finance/chart/" + java.net.URLEncoder.encode(y, "UTF-8") + "?interval=" + iv + "&range=" + range + "&includePrePost=false";
        return new JSONObject(get(url)).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
    }
    private static List<Engine.C> yahoo(String sym, String tf, int limit) throws Exception {
        String iv, rg;
        switch (tf) { case "5m": iv = "5m"; rg = "5d"; break; case "15m": iv = "15m"; rg = "1mo"; break; case "1h": iv = "60m"; rg = "3mo"; break;
            case "4h": iv = "60m"; rg = "1y"; break; case "1w": iv = "1wk"; rg = "5y"; break; default: iv = "1d"; rg = "2y"; }
        JSONObject r = yahooRaw(sym, iv, rg);
        JSONArray ts = r.getJSONArray("timestamp");
        JSONObject q = r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray o = q.getJSONArray("open"), h = q.getJSONArray("high"), l = q.getJSONArray("low"), c = q.getJSONArray("close"), v = q.getJSONArray("volume");
        List<Engine.C> out = new ArrayList<>();
        for (int i = 0; i < ts.length(); i++) {
            if (o.isNull(i) || c.isNull(i)) continue;
            out.add(new Engine.C(ts.getLong(i) * 1000L, o.getDouble(i), h.getDouble(i), l.getDouble(i), c.getDouble(i), v.isNull(i) ? 0 : v.getDouble(i)));
        }
        if (tf.equals("4h")) {                                     // 1 saatliklerden 4 saatlik
            long ms = TF_MS.get("4h"); Map<Long, double[]> b = new java.util.TreeMap<>();
            for (Engine.C x : out) { long t = (x.t / ms) * ms; double[] a = b.get(t);
                if (a == null) b.put(t, new double[]{x.o, x.h, x.l, x.c, x.v});
                else { a[1] = Math.max(a[1], x.h); a[2] = Math.min(a[2], x.l); a[3] = x.c; a[4] += x.v; } }
            out = new ArrayList<>();
            for (Map.Entry<Long, double[]> e : b.entrySet()) { double[] a = e.getValue(); out.add(new Engine.C(e.getKey(), a[0], a[1], a[2], a[3], a[4])); }
        }
        return out.size() > limit ? out.subList(out.size() - limit, out.size()) : out;
    }
    static double yahooPrice(String sym) throws Exception {
        return yahooRaw(sym, "1m", "1d").getJSONObject("meta").getDouble("regularMarketPrice");
    }

    private static List<Engine.C> kraken(String pair, String tf, int limit) throws Exception {
        long min = TF_MS.get(tf) / 60_000L;
        JSONObject d = new JSONObject(get("https://api.kraken.com/0/public/OHLC?pair=" + pair + "&interval=" + min));
        JSONObject r = d.getJSONObject("result");
        JSONArray rows = null;
        for (Iterator<String> it = r.keys(); it.hasNext(); ) { String k = it.next(); if (!k.equals("last")) rows = r.getJSONArray(k); }
        List<Engine.C> out = new ArrayList<>();
        if (rows == null) return out;
        for (int i = Math.max(0, rows.length() - limit); i < rows.length(); i++) {
            JSONArray k = rows.getJSONArray(i);
            out.add(new Engine.C(k.getLong(0) * 1000L, k.getDouble(1), k.getDouble(2), k.getDouble(3), k.getDouble(4), k.getDouble(6)));
        }
        return out;
    }
    static String get(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(10_000); c.setReadTimeout(15_000);
        c.setRequestProperty("User-Agent", "AlbayTradingBot/1.2");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new String(bo.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { c.disconnect(); }
    }

    /* ---------------- Biçim ---------------- */
    static String mkTag(String mk) { return mk.equals("spot") ? "SPOT" : mk.equals("fx") ? "FOREX" : mk.equals("stock") ? "STOCK" : "FUTURES"; }
    static boolean isFx(String s) { return !isStock(s) && s.matches("^(EUR|GBP|USD|AUD|XAU|XAG)[A-Z]{3}$"); }
    static String base(String s) {
        if (isStock(s)) return s.replace("STK:", "").replaceAll("\\.(DE|IS)$", "");
        if (isFx(s)) return s.substring(0, 3) + "/" + s.substring(3);
        return s.replace("_S", "").replaceAll("USDT$", "");
    }
    static String fmt(String sym, double p) {
        if (isStock(sym)) return String.format(Locale.US, p < 10 ? "%.3f" : "%.2f", p);
        if (isFx(sym)) {
            int dec = sym.endsWith("JPY") || sym.startsWith("XAG") ? 3 : sym.startsWith("XAU") ? 2 : 5;
            return String.format(Locale.US, "%." + dec + "f", p);
        }
        if (p >= 1000) return String.format(Locale.US, "%.2f", p);
        if (p >= 1) return String.format(Locale.US, "%.3f", p);
        if (p >= 0.01) return String.format(Locale.US, "%.5f", p);
        return String.format(Locale.US, "%.7f", p);
    }

    /* ---------------- Bildirim metinleri (TR / EN / DE) ---------------- */
    static final class Txt {
        final String lang; final JSONObject models;
        Txt(JSONObject cfg) { String l = cfg.optString("lang", "tr"); lang = (l.equals("en") || l.equals("de")) ? l : "tr"; models = cfg.optJSONObject("models"); }
        String model(String id) { return models != null ? models.optString(id, id) : id; }
        String s(String key) { Map<String, String> d = DICT.get(lang); String v = d.get(key); return v != null ? v : DICT.get("tr").getOrDefault(key, key); }
        String f(String key, String... kv) { String v = s(key); for (int i = 0; i + 1 < kv.length; i += 2) v = v.replace("{" + kv[i] + "}", kv[i + 1]); return v; }
    }
    static final Map<String, Map<String, String>> DICT = new HashMap<>();
    private static void put(String lang, String... kv) { Map<String, String> m = new HashMap<>(); for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]); DICT.put(lang, m); }
    static {
        put("tr",
            "newSig", "{dot} {mk} · {c} {tf} {m} {side} · {st}", "newB", "Giriş {e} · SL {s} · RR {rr}",
            "tp", "✅ {mk} · {c} {tf} {m} · {tp}", "tp1B", "Stop girişe çekildi (başa baş).", "tp2B", "Stop TP1 seviyesine çekildi.",
            "runner", "🏃 {mk} · {c} {tf} {m} · TP3 ✅ Runner", "runnerB", "Hacim ve momentum onaylı; kalan %25 trend sürdükçe taşınır, stop TP2’de ve iz sürüyor.",
            "closed", "{icon} {mk} · {c} {tf} {m} {side} kapandı · {type}", "priceB", "Fiyat: {p}",
            "tradeTp", "✅ {mk} · İşlemin {c}: {tp}", "tradeRunner", "🏃 {mk} · İşlemin {c}: TP3 ✅ Runner", "tradeClosed", "{icon} {mk} · İşlemin kapandı: {c} {side} · {type}",
            "st.strong", "GÜÇLÜ", "st.medium", "ORTA", "st.weak", "ZAYIF",
            "type.SL", "STOP", "type.BE", "BAŞA BAŞ", "type.TP1SL", "TP1 STOP", "type.TP3", "TP3", "type.RUN", "RUNNER");
        put("en",
            "newSig", "{dot} {mk} · {c} {tf} {m} {side} · {st}", "newB", "Entry {e} · SL {s} · RR {rr}",
            "tp", "✅ {mk} · {c} {tf} {m} · {tp}", "tp1B", "Stop moved to entry (breakeven).", "tp2B", "Stop moved to TP1.",
            "runner", "🏃 {mk} · {c} {tf} {m} · TP3 ✅ Runner", "runnerB", "Volume and momentum confirmed; the remaining 25% rides the trend with the stop at TP2 and trailing.",
            "closed", "{icon} {mk} · {c} {tf} {m} {side} closed · {type}", "priceB", "Price: {p}",
            "tradeTp", "✅ {mk} · Your trade {c}: {tp}", "tradeRunner", "🏃 {mk} · Your trade {c}: TP3 ✅ Runner", "tradeClosed", "{icon} {mk} · Your trade closed: {c} {side} · {type}",
            "st.strong", "STRONG", "st.medium", "MEDIUM", "st.weak", "WEAK",
            "type.SL", "STOP", "type.BE", "BREAKEVEN", "type.TP1SL", "TP1 STOP", "type.TP3", "TP3", "type.RUN", "RUNNER");
        put("de",
            "newSig", "{dot} {mk} · {c} {tf} {m} {side} · {st}", "newB", "Einstieg {e} · SL {s} · CRV {rr}",
            "tp", "✅ {mk} · {c} {tf} {m} · {tp}", "tp1B", "Stopp auf Einstieg gezogen (Break-even).", "tp2B", "Stopp auf TP1 nachgezogen.",
            "runner", "🏃 {mk} · {c} {tf} {m} · TP3 ✅ Runner", "runnerB", "Volumen und Momentum bestätigt; die restlichen 25 % laufen mit dem Trend, Stopp auf TP2 und nachgezogen.",
            "closed", "{icon} {mk} · {c} {tf} {m} {side} geschlossen · {type}", "priceB", "Kurs: {p}",
            "tradeTp", "✅ {mk} · Dein Trade {c}: {tp}", "tradeRunner", "🏃 {mk} · Dein Trade {c}: TP3 ✅ Runner", "tradeClosed", "{icon} {mk} · Dein Trade wurde geschlossen: {c} {side} · {type}",
            "st.strong", "STARK", "st.medium", "MITTEL", "st.weak", "SCHWACH",
            "type.SL", "STOPP", "type.BE", "BREAK-EVEN", "type.TP1SL", "TP1-STOPP", "type.TP3", "TP3", "type.RUN", "RUNNER");
    }
}
