package com.albay.tradingbot;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import android.net.wifi.WifiManager;

/** Ön plan servisi + mum kapanışı zamanlayıcısı. Uygulama kapalıyken taramayı yürütür. */
public class BotService extends Service {

    private static final AtomicBoolean scanning = new AtomicBoolean(false);
    // Sürekli canlı mod: CPU ve Wi-Fi uyanık kalır, ekran kapalı/kilitliyken de 15 sn'de bir kontrol yapılır
    private static PowerManager.WakeLock liveLock;
    private static WifiManager.WifiLock wifiLock;
    private static ScheduledExecutorService loop;
    private static final AtomicBoolean pricing = new AtomicBoolean(false);

    static boolean liveEnabled(Context c) { return Scanner.config(c).optBoolean("live", true); }

    static synchronized void applyLive(Context c) {
        final Context app = c.getApplicationContext();
        if (liveEnabled(app)) {
            if (liveLock == null) {
                liveLock = app.getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "albay:live");
                liveLock.setReferenceCounted(false);
                liveLock.acquire();
            }
            if (wifiLock == null) {
                try {
                    WifiManager wm = app.getSystemService(WifiManager.class);
                    int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                    wifiLock = wm.createWifiLock(mode, "albay:wifi");
                    wifiLock.setReferenceCounted(false);
                    wifiLock.acquire();
                } catch (Exception ignored) { }
            }
            if (loop == null) {
                loop = Executors.newSingleThreadScheduledExecutor();
                loop.scheduleWithFixedDelay(() -> {
                    try {
                        if (Scanner.dueAny(app)) scanNow(app, false);
                        if (pricing.compareAndSet(false, true)) {
                            try { new Scanner(app).checkPrices(); } finally { pricing.set(false); }
                        }
                        Telegram.reportTick(app);
                        try { Live.tick(app); } catch (Throwable ignored) { }      // canlı pozisyon senkronu + günlük zarar kontrolü (~60 sn)
                        app.getSharedPreferences(Scanner.PREF, MODE_PRIVATE).edit().putLong("liveTick", System.currentTimeMillis()).apply();
                    } catch (Throwable ignored) { }
                }, 5, 15, TimeUnit.SECONDS);
            }
        } else {
            if (loop != null) { loop.shutdownNow(); loop = null; }
            if (liveLock != null) { if (liveLock.isHeld()) liveLock.release(); liveLock = null; }
            if (wifiLock != null) { try { if (wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { } wifiLock = null; }
        }
    }

    @Override
    public void onDestroy() {
        if (loop != null) { loop.shutdownNow(); loop = null; }
        if (liveLock != null && liveLock.isHeld()) liveLock.release(); liveLock = null;
        if (wifiLock != null) { try { if (wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) { } wifiLock = null; }
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NativeBridge.createChannels(this);
        Notification n = new NotificationCompat.Builder(this, NativeBridge.CH_SERVICE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Albay Trading Bot")
                .setContentText(liveEnabled(this) ? "Sürekli canlı tarama açık" : "Piyasalar mum kapanışlarında taranıyor")
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(NativeBridge.openApp(this))
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
        applyLive(this);
        scheduleNext(this);
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    static void ensureRunning(Context c) {
        try { c.startForegroundService(new Intent(c, BotService.class)); } catch (Exception ignored) { }
    }

    /** Taramayı ayrı iş parçacığında çalıştırır; CPU uyanık kalır. */
    static void scanNow(Context c) { scanNow(c, false); }
    static void scanNow(Context c, boolean force) {
        final Context app = c.getApplicationContext();
        if (!scanning.compareAndSet(false, true)) { scheduleNext(app); return; }
        PowerManager pm = app.getSystemService(PowerManager.class);
        final PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "albay:scan");
        wl.acquire(5 * 60 * 1000L);
        new Thread(() -> {
            try { new Scanner(app).runScan(force); }
            catch (Throwable t) {
                app.getSharedPreferences(Scanner.PREF, MODE_PRIVATE).edit().putString("lastError", String.valueOf(t)).apply();
            } finally {
                scanning.set(false);
                scheduleNext(app);
                if (wl.isHeld()) wl.release();
            }
        }, "albay-scan").start();
    }

    /** Bir sonraki mum kapanışından 8 sn sonrasına alarm kurar. */
    static void scheduleNext(Context c) {
        JSONObject cfg = Scanner.config(c);
        List<String> tfs = Scanner.tfs(cfg);
        long now = System.currentTimeMillis(), next = Long.MAX_VALUE;
        for (String tf : tfs) { long ms = Scanner.TF_MS.get(tf); next = Math.min(next, (now / ms + 1) * ms + 8_000L); }
        if (next == Long.MAX_VALUE) next = now + 5 * 60_000L;
        c.getSharedPreferences(Scanner.PREF, MODE_PRIVATE).edit().putLong("nextAt", next).apply();
        AlarmManager am = c.getSystemService(AlarmManager.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, 21, new Intent(c, AlarmReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi);
        }
    }
}
