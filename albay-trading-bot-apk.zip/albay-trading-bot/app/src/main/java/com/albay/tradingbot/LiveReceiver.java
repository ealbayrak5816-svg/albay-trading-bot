package com.albay.tradingbot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Bildirimdeki "Onayla / Reddet" düğmeleri (sadece bu uygulama tetikleyebilir: exported=false) */
public class LiveReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (i == null) return;
        String id = i.getStringExtra("id");
        if (id == null) return;
        if (Live.ACT_OK.equals(i.getAction())) Live.approve(c, id);
        else if (Live.ACT_NO.equals(i.getAction())) Live.reject(c, id);
    }
}
