package com.albay.tradingbot;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Canlı işlem motoru + risk bekçisi (MEXC Futures).
 *
 * Kurallar Java tarafında uygulanır; HTML arayüzü sadece ayar gönderir, kuralları atlayamaz:
 *  - Mod: off (kapalı) · confirm (her emir onayla) · auto (eşik karşılanmadan kilitli)
 *  - Her emirde borsada stop-loss zorunlu; stop eklenemezse pozisyon hemen kapatılır
 *  - İşlem başına en fazla marj ve en fazla risk ($), kaldıraç tavanı, likidasyon stoptan uzakta
 *  - En fazla açık pozisyon, günlük en fazla işlem, günlük zarar limiti (aşılınca gün sonuna kadar durur)
 *  - Fiyat sinyalden fazla kaydıysa emir gönderilmez
 *  - Acil durdurma: emirleri iptal eder, pozisyonları kapatır, motoru kilitler
 * Tüm borsa işlemleri tek iş parçacığında sırayla yürür (çift emir olmaz).
 */
final class Live {

    static final String PREF = "albay_live";
    static final String ACT_OK = "com.albay.tradingbot.LIVE_APPROVE", ACT_NO = "com.albay.tradingbot.LIVE_REJECT";
    private static final ExecutorService EX = Executors.newSingleThreadExecutor();

    /* Sabit üst sınırlar: ayarlarla aşılamaz */
    static final int HARD_MAX_LEV = 20, HARD_MAX_OPEN = 10, HARD_MAX_DAY = 50;
    static final int GATE_N = 100; static final double GATE_DD = 20;      // otomatik mod eşiği: ≥100 işlem, Ø R > 0, max DD ≤ 20R

    /* ================= Ayarlar ================= */
    static JSONObject risk(Context c) {
        JSONObject d = new JSONObject();
        try {
            d.put("mode", "off"); d.put("marginUsd", 5); d.put("riskUsd", 1); d.put("maxLev", 5); d.put("maxOpen", 2);
            d.put("dayLossUsd", 10); d.put("maxTradesDay", 5); d.put("strongOnly", true); d.put("confirmMin", 5);
            d.put("slipPct", 0.5); d.put("slMinPct", 0.15); d.put("slMaxPct", 10);
            JSONObject s = new JSONObject(sp(c).getString("risk", "{}"));
            for (java.util.Iterator<String> it = s.keys(); it.hasNext(); ) { String k = it.next(); d.put(k, s.get(k)); }
        } catch (Exception ignored) { }
        return d;
    }

    /** Arayüzden gelen ayar; doğrulanır ve sınırlanır. Dönüş: "ok" veya hata kodu */
    static synchronized String setRisk(Context c, String json) {
        try {
            JSONObject in = new JSONObject(json), r = risk(c);
            r.put("marginUsd", clamp(in.optDouble("marginUsd", r.getDouble("marginUsd")), 1, 100000));
            r.put("riskUsd", clamp(in.optDouble("riskUsd", r.getDouble("riskUsd")), 0.1, 100000));
            r.put("maxLev", (int) clamp(in.optInt("maxLev", r.getInt("maxLev")), 1, HARD_MAX_LEV));
            r.put("maxOpen", (int) clamp(in.optInt("maxOpen", r.getInt("maxOpen")), 1, HARD_MAX_OPEN));
            r.put("dayLossUsd", clamp(in.optDouble("dayLossUsd", r.getDouble("dayLossUsd")), 0.5, 1000000));
            r.put("maxTradesDay", (int) clamp(in.optInt("maxTradesDay", r.getInt("maxTradesDay")), 1, HARD_MAX_DAY));
            r.put("strongOnly", in.optBoolean("strongOnly", r.getBoolean("strongOnly")));
            r.put("confirmMin", (int) clamp(in.optInt("confirmMin", r.getInt("confirmMin")), 1, 30));
            r.put("slipPct", clamp(in.optDouble("slipPct", r.getDouble("slipPct")), 0.05, 3));
            if (in.has("gate")) r.put("gate", in.getJSONObject("gate"));
            String mode = in.optString("mode", r.getString("mode"));
            if (!mode.equals("off")) {
                if (!Vault.has(c)) return "noKey";
                JSONObject lt = lastTest(c);
                if (lt == null || !lt.optBoolean("ok")) return "noTest";
                if (halted(c) != null) return "halted";
            }
            if (mode.equals("auto") && !gateOk(r.optJSONObject("gate"))) return "autoLocked";
            if (!mode.equals("off") && !mode.equals("confirm") && !mode.equals("auto")) mode = "off";
            if (!mode.equals(r.getString("mode"))) log(c, true, "mode → " + mode);
            r.put("mode", mode);
            sp(c).edit().putString("risk", r.toString()).apply();
            return "ok";
        } catch (Exception e) { return "err"; }
    }
    static boolean gateOk(JSONObject g) {
        return g != null && g.optInt("n", 0) >= GATE_N && g.optDouble("avgR", -1) > 0 && g.optDouble("maxDD", 999) <= GATE_DD;
    }
    private static double clamp(double v, double lo, double hi) { return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }

    /* ================= API anahtarı ================= */
    static String saveKey(Context c, String key, String secret) {
        if (key == null || secret == null || key.trim().length() < 8 || secret.trim().length() < 8) return "badKey";
        try {
            Vault.save(c, key, secret);
            sp(c).edit().remove("test").apply();
            log(c, true, "API key saved " + Vault.mask(key.trim()));
            test(c);
            return "ok";
        } catch (Exception e) { return "vault"; }
    }
    static void deleteKey(Context c) {
        Vault.clear(c);
        try { JSONObject r = risk(c); r.put("mode", "off"); sp(c).edit().putString("risk", r.toString()).remove("test").apply(); } catch (Exception ignored) { }
        log(c, true, "API key deleted, mode → off");
    }
    static JSONObject lastTest(Context c) {
        try { String s = sp(c).getString("test", null); return s == null ? null : new JSONObject(s); } catch (Exception e) { return null; }
    }

    /** Bağlantı testi (sadece okuma: bakiye ve pozisyon modu) */
    static void test(Context c) {
        final Context app = c.getApplicationContext();
        EX.submit(() -> {
            JSONObject o = new JSONObject();
            try {
                o.put("t", System.currentTimeMillis());
                Mexc m = client(app);
                if (m == null) throw new Mexc.ApiError(0, "noKey");
                JSONObject u = m.usdt();
                o.put("ok", true);
                o.put("eq", u.optDouble("equity", 0));
                o.put("avail", u.optDouble("availableBalance", 0));
                try { o.put("pm", m.positionMode()); } catch (Exception ignored) { }
                saveAccount(app, u);
                log(app, true, "test OK · equity " + usd(u.optDouble("equity", 0)));
            } catch (Exception e) {
                try { o.put("ok", false); o.put("err", e.getMessage()); } catch (Exception ignored) { }
                log(app, false, "test: " + e.getMessage());
            }
            sp(app).edit().putString("test", o.toString()).apply();
        });
    }

    /* ================= Sinyal → emir ================= */
    /** Uygulamanın bot sinyali. Dönüş: off / skip:<neden> / pending / queued */
    static synchronized String onSignal(Context c, String json) {
        final Context app = c.getApplicationContext();
        try {
            JSONObject r = risk(app);
            String mode = r.getString("mode");
            if (mode.equals("off")) return "off";
            JSONObject s = new JSONObject(json);
            String why = preCheck(app, r, s);
            if (why != null) { log(app, false, s.optString("sym") + " " + s.optString("side") + " · skip: " + why); return "skip:" + why; }
            if (mode.equals("confirm")) {
                s.put("createdAt", System.currentTimeMillis());
                s.put("expiresAt", System.currentTimeMillis() + r.getInt("confirmMin") * 60_000L);
                JSONArray p = arr(app, "pending"); p.put(s); put(app, "pending", p);
                notifyPending(app, s, r);
                log(app, true, s.optString("sym") + " " + s.optString("side") + " · waiting for approval");
                return "pending";
            }
            if (mode.equals("auto")) {
                if (!gateOk(r.optJSONObject("gate"))) return "skip:autoLocked";
                EX.submit(() -> execute(app, s));
                return "queued";
            }
        } catch (Exception e) { return "skip:err"; }
        return "off";
    }

    /** Ağ gerektirmeyen ön kontroller; uygunsa null */
    private static String preCheck(Context c, JSONObject r, JSONObject s) throws Exception {
        if (!Vault.has(c)) return "noKey";
        if (halted(c) != null) return "halted";
        if (!"crypto".equals(s.optString("market", "crypto"))) return "market";
        if (r.getBoolean("strongOnly") && !"strong".equals(s.optString("strength"))) return "notStrong";
        String id = s.getString("id"), sym = s.getString("sym");
        boolean L = "LONG".equals(s.getString("side"));
        double entry = s.getDouble("entry"), stop = s.getDouble("stop");
        if (!(entry > 0) || !(stop > 0) || (L ? stop >= entry : stop <= entry)) return "badStop";
        double sp = Math.abs(entry - stop) / entry * 100;
        if (sp < r.getDouble("slMinPct") || sp > r.getDouble("slMaxPct")) return "stopDist";
        JSONArray tr = arr(c, "trades"), pe = arr(c, "pending");
        int open = 0;
        for (int i = 0; i < tr.length(); i++) {
            JSONObject t = tr.getJSONObject(i);
            if (t.optBoolean("closed")) continue;
            open++;
            if (t.getString("id").equals(id) || t.getString("sym").equals(sym)) return "dup";
        }
        for (int i = 0; i < pe.length(); i++) {
            JSONObject t = pe.getJSONObject(i);
            if (t.getString("id").equals(id) || t.getString("sym").equals(sym)) return "dup";
        }
        if (open >= r.getInt("maxOpen")) return "maxOpen";
        if (day(c).optInt("trades", 0) >= r.getInt("maxTradesDay")) return "maxDay";
        return null;
    }

    static void approve(Context c, String id) {
        final Context app = c.getApplicationContext();
        JSONObject s = takePending(app, id);
        cancelNote(app, id);
        if (s == null) { log(app, false, "approve: not found / expired"); return; }
        if (System.currentTimeMillis() > s.optLong("expiresAt", 0)) { log(app, false, s.optString("sym") + " · approval expired"); return; }
        try {
            if (!risk(app).getString("mode").equals("confirm") && !risk(app).getString("mode").equals("auto")) { log(app, false, "approve: engine is off"); return; }
        } catch (Exception ignored) { }
        log(app, true, s.optString("sym") + " " + s.optString("side") + " · approved");
        EX.submit(() -> execute(app, s));
    }
    static void reject(Context c, String id) {
        JSONObject s = takePending(c, id);
        cancelNote(c, id);
        if (s != null) log(c, true, s.optString("sym") + " " + s.optString("side") + " · rejected");
    }
    private static synchronized JSONObject takePending(Context c, String id) {
        JSONArray p = arr(c, "pending"), keep = new JSONArray(); JSONObject hit = null;
        for (int i = 0; i < p.length(); i++) { JSONObject o = p.optJSONObject(i); if (o == null) continue; if (o.optString("id").equals(id)) hit = o; else keep.put(o); }
        put(c, "pending", keep);
        return hit;
    }

    /** Emri borsaya gönderir. Sadece EX iş parçacığında çalışır. */
    private static void execute(Context c, JSONObject s) {
        String sym = s.optString("sym"), side = s.optString("side"), tag = sym + " " + side;
        try {
            JSONObject r = risk(c);
            String why = preCheck(c, r, s);
            if (why != null) { log(c, false, tag + " · skip: " + why); return; }
            Mexc m = client(c);
            if (m == null) { log(c, false, tag + " · no key"); return; }
            String mx = Mexc.sym(sym);
            boolean L = "LONG".equals(side);

            // 1) Günlük zarar limiti (hesap değerine göre)
            JSONObject u = m.usdt(); saveAccount(c, u);
            if (dayLossHit(c, r, u.optDouble("equity", 0))) { log(c, false, tag + " · daily loss limit reached"); return; }

            // 2) Borsadaki açık pozisyonlar (elle açılanlar dahil sayılır)
            JSONArray pos = m.openPositions(null);
            if (pos.length() >= r.getInt("maxOpen")) { log(c, false, tag + " · skip: maxOpen (exchange " + pos.length() + ")"); return; }
            for (int i = 0; i < pos.length(); i++) if (mx.equals(pos.getJSONObject(i).optString("symbol"))) { log(c, false, tag + " · skip: position already open on exchange"); return; }

            // 3) Fiyat kayması
            double entry = s.getDouble("entry"), stop = s.getDouble("stop");
            JSONArray tpA = s.getJSONArray("tp");
            double tp1 = tpA.getDouble(0);
            double px = Mexc.lastPrice(mx);
            double slip = Math.abs(px - entry) / entry * 100;
            if (slip > r.getDouble("slipPct")) { log(c, false, tag + String.format(Locale.US, " · skip: price moved %.2f%%", slip)); return; }
            if (L ? (px <= stop || px >= tp1) : (px >= stop || px <= tp1)) { log(c, false, tag + " · skip: price beyond stop/TP1"); return; }

            // 4) Boyut ve kaldıraç
            JSONObject ct = Mexc.contract(mx);
            double cs = ct.getDouble("contractSize"), minVol = ct.optDouble("minVol", 1), vu = ct.optDouble("volUnit", 1), pu = ct.optDouble("priceUnit", 0);
            int ctMax = ct.optInt("maxLeverage", HARD_MAX_LEV);
            double stopFrac = Math.abs(px - stop) / px;
            int safeLev = Math.max(1, (int) Math.floor(1 / (stopFrac * 2)));   // likidasyon stoptan en az 2 kat uzakta
            int levCap = Math.max(1, Math.min(Math.min(r.getInt("maxLev"), HARD_MAX_LEV), Math.min(safeLev, ctMax)));
            double marginMax = r.getDouble("marginUsd"), riskMax = r.getDouble("riskUsd");
            double notional = Math.min(marginMax * levCap, riskMax / stopFrac);
            int lev = Math.max(1, Math.min(levCap, (int) Math.ceil(notional / marginMax)));
            double margin = notional / lev;
            if (margin > u.optDouble("availableBalance", 0) * 0.95) { log(c, false, tag + " · skip: not enough available balance"); return; }
            double vol = Math.floor(notional / (px * cs) / vu) * vu;
            if (vol < minVol) { log(c, false, tag + String.format(Locale.US, " · skip: size below exchange minimum (min ≈ %s)", usd(minVol * px * cs))); return; }
            double sl = roundTick(stop, pu);
            double riskUsd = vol * cs * Math.abs(px - sl);

            // 5) Emir (borsada stop-loss ile)
            String ext = "albay" + Long.toString(System.currentTimeMillis(), 36);
            String orderId = null; Exception sendErr = null;
            try { orderId = m.submit(mx, L ? 1 : 3, vol, px, lev, sl, null, ext); }
            catch (Mexc.ApiError e) { log(c, false, tag + " · order rejected: " + hint(e)); return; }
            catch (Exception e) { sendErr = e; }              // ağ hatası: emir gitmiş olabilir → borsadan kontrol

            // 6) Pozisyonu doğrula
            JSONObject p = null;
            for (int k = 0; k < 4 && p == null; k++) { Thread.sleep(1500); p = findPos(m.openPositions(mx), mx, L); }
            if (p == null) {
                log(c, false, tag + (sendErr != null ? " · network error, no position found: " + sendErr.getMessage() : " · order sent but no position found (id " + orderId + ")"));
                return;
            }
            // 7) Stop borsada var mı? Yoksa korumasız pozisyon bırakılmaz
            boolean hasSl = false;
            try {
                JSONArray so = m.stopOrders(mx);
                for (int i = 0; i < so.length(); i++) { if (so.getJSONObject(i).optDouble("stopLossPrice", 0) > 0) { hasSl = true; break; } }
            } catch (Exception e) { hasSl = true; log(c, false, tag + " · could not verify stop: " + e.getMessage()); }  // doğrulanamadı ≠ yok
            if (!hasSl) {
                try { m.submit(mx, L ? 4 : 2, p.optDouble("holdVol", vol), Mexc.lastPrice(mx), 0, null, p.optLong("positionId"), null); } catch (Exception ignored) { }
                log(c, false, tag + " · NO STOP-LOSS on exchange → position closed immediately");
                halt(c, "noStop", 0);
                note(c, "⚠️ " + title(c, sym, side), T(c, "noStop"));
                return;
            }

            JSONObject t = new JSONObject();
            t.put("id", s.getString("id")); t.put("key", s.optString("key")); t.put("sym", sym); t.put("mx", mx); t.put("side", side);
            t.put("tf", s.optString("tf")); t.put("model", s.optString("model"));
            t.put("sigEntry", entry); t.put("fill", p.optDouble("openAvgPrice", px)); t.put("sl", sl); t.put("sl0", sl); t.put("tp", tpA);
            t.put("vol0", p.optDouble("holdVol", vol)); t.put("vol", p.optDouble("holdVol", vol)); t.put("lev", lev);
            t.put("margin", margin); t.put("riskUsd", riskUsd); t.put("positionId", p.optLong("positionId"));
            t.put("orderId", orderId); t.put("cs", cs); t.put("minVol", minVol); t.put("vu", vu); t.put("pu", pu);
            t.put("openedAt", System.currentTimeMillis()); t.put("ev", new JSONArray());
            JSONArray tr = arr(c, "trades"); tr.put(t); put(c, "trades", trimTrades(tr));
            JSONObject d = day(c); d.put("trades", d.optInt("trades", 0) + 1); put(c, "day", d);
            double fSlip = (t.getDouble("fill") - entry) / entry * 100 * (L ? 1 : -1);
            log(c, true, String.format(Locale.US, "%s · OPEN vol %s · %dx · fill %s · SL %s · risk %s · slippage %+.2f%%",
                    tag, num(vol), lev, Scanner.fmt(sym, t.getDouble("fill")), Scanner.fmt(sym, sl), usd(riskUsd), fSlip));
            note(c, "✅ " + title(c, sym, side), String.format(Locale.US, T(c, "opened"), lev, usd(margin), Scanner.fmt(sym, t.getDouble("fill")), Scanner.fmt(sym, sl), usd(riskUsd)));
        } catch (Exception e) {
            log(c, false, tag + " · error: " + e.getMessage());
        }
    }

    /* ================= Pozisyon yönetimi (TP1 / TP2 / runner / kapanış) ================= */
    /** Sinyal olayı (uygulamadan veya arka plan motorundan; aynı olay iki kez işlenmez) */
    static void onEvent(Context c, String id, String ev) {
        if (id == null || ev == null) return;
        final Context app = c.getApplicationContext();
        if (findTrade(app, id) == null) return;
        EX.submit(() -> manage(app, id, ev));
    }

    private static void manage(Context c, String id, String ev) {
        JSONObject t = findTrade(c, id);
        if (t == null || t.optBoolean("closed")) return;
        try {
            JSONArray done = t.optJSONArray("ev"); if (done == null) done = new JSONArray();
            for (int i = 0; i < done.length(); i++) if (ev.equals(done.optString(i))) return;
            done.put(ev); t.put("ev", done); saveTrade(c, t);
            Mexc m = client(c); if (m == null) return;
            String mx = t.getString("mx"), tag = t.getString("sym") + " " + t.getString("side");
            boolean L = "LONG".equals(t.getString("side"));
            JSONObject p = findPos(m.openPositions(mx), mx, L);
            if (p == null) { closed(c, t, "exchange", null); return; }
            double hold = p.optDouble("holdVol", t.optDouble("vol")), vol0 = t.getDouble("vol0");
            JSONArray tp = t.getJSONArray("tp");
            switch (ev) {
                case "TP1": partial(c, m, t, p, vol0 * 0.25, hold); moveStop(c, m, t, t.getDouble("fill")); break;
                case "TP2": partial(c, m, t, p, vol0 * 0.50, hold); moveStop(c, m, t, tp.getDouble(0)); break;
                case "RUNON": moveStop(c, m, t, tp.getDouble(1)); break;
                default:                                           // SL, BE, TP1SL, TP3, RUN, EXP, MAN
                    double px = Mexc.lastPrice(mx);
                    m.submit(mx, L ? 4 : 2, hold, px, 0, null, p.optLong("positionId"), null);
                    closed(c, t, ev, px);
                    log(c, true, tag + " · CLOSE " + ev + " · vol " + num(hold));
            }
        } catch (Exception e) {
            log(c, false, "manage " + id + " " + ev + ": " + e.getMessage());
        }
    }
    private static void partial(Context c, Mexc m, JSONObject t, JSONObject p, double want, double hold) throws Exception {
        double vu = t.optDouble("vu", 1), minVol = t.optDouble("minVol", 1);
        double v = Math.floor(want / vu) * vu;
        if (v < minVol || v >= hold) { log(c, true, t.getString("sym") + " · partial close skipped (size " + num(v) + ")"); return; }
        boolean L = "LONG".equals(t.getString("side"));
        m.submit(t.getString("mx"), L ? 4 : 2, v, Mexc.lastPrice(t.getString("mx")), 0, null, p.optLong("positionId"), null);
        t.put("vol", hold - v); saveTrade(c, t);
        log(c, true, t.getString("sym") + " " + t.getString("side") + " · partial close vol " + num(v));
    }
    private static void moveStop(Context c, Mexc m, JSONObject t, double price) throws Exception {
        double sl = roundTick(price, t.optDouble("pu", 0));
        JSONArray so = m.stopOrders(t.getString("mx"));
        long oid = 0;
        for (int i = 0; i < so.length(); i++) {
            JSONObject o = so.getJSONObject(i);
            if (o.optDouble("stopLossPrice", 0) > 0 && (o.optLong("positionId", 0) == 0 || o.optLong("positionId") == t.optLong("positionId"))) { oid = o.optLong("id", o.optLong("orderId", 0)); break; }
        }
        if (oid == 0) { log(c, false, t.getString("sym") + " · stop could not be moved (no stop order found); original stop stays"); return; }
        try {
            m.changeStop(oid, sl);
            t.put("sl", sl); saveTrade(c, t);
            log(c, true, t.getString("sym") + " · stop → " + Scanner.fmt(t.getString("sym"), sl));
        } catch (Exception e) {
            log(c, false, t.getString("sym") + " · stop move failed: " + e.getMessage() + " (previous stop stays)");
        }
    }
    private static void closed(Context c, JSONObject t, String why, Double px) throws Exception {
        t.put("closed", true); t.put("closedAt", System.currentTimeMillis()); t.put("why", why);
        if (px != null) {
            boolean L = "LONG".equals(t.getString("side"));
            t.put("exit", px);
            t.put("movePct", (px - t.getDouble("fill")) / t.getDouble("fill") * 100 * (L ? 1 : -1));
        }
        saveTrade(c, t);
        if (why.equals("exchange")) log(c, true, t.getString("sym") + " " + t.getString("side") + " · closed on exchange (stop / manual)");
        note(c, "🏁 " + title(c, t.getString("sym"), t.getString("side")), T(c, why.equals("exchange") ? "closedEx" : "closed"));
    }

    /* ================= Periyodik senkron (BotService döngüsü, ~60 sn) ================= */
    private static long lastSync = 0;
    static void tick(Context c) {
        long now = System.currentTimeMillis();
        if (now - lastSync < 60_000L || !Vault.has(c)) return;
        lastSync = now;
        final Context app = c.getApplicationContext();
        expirePending(app);
        boolean any = false;
        JSONArray tr = arr(app, "trades");
        for (int i = 0; i < tr.length(); i++) if (!tr.optJSONObject(i).optBoolean("closed")) any = true;
        boolean on = !risk(app).optString("mode", "off").equals("off");
        if (!any && !on) return;
        EX.submit(() -> sync(app));
    }
    private static void sync(Context c) {
        try {
            Mexc m = client(c); if (m == null) return;
            JSONObject u = m.usdt(); saveAccount(c, u);
            JSONObject r = risk(c);
            if (dayLossHit(c, r, u.optDouble("equity", 0))) { /* halt() içinde bildirildi */ }
            JSONArray pos = m.openPositions(null), tr = arr(c, "trades");
            for (int i = 0; i < tr.length(); i++) {
                JSONObject t = tr.getJSONObject(i);
                if (t.optBoolean("closed")) continue;
                boolean found = false;
                for (int j = 0; j < pos.length(); j++) {
                    JSONObject p = pos.getJSONObject(j);
                    if (p.optLong("positionId") == t.optLong("positionId")) { found = true; t.put("vol", p.optDouble("holdVol", t.optDouble("vol"))); t.put("upnl", p.optDouble("unrealised", p.optDouble("pnl", 0))); break; }
                }
                if (!found) closed(c, t, "exchange", null); else saveTrade(c, t);
            }
            sp(c).edit().putLong("sync", System.currentTimeMillis()).remove("syncErr").apply();
        } catch (Exception e) {
            sp(c).edit().putString("syncErr", String.valueOf(e.getMessage())).apply();
        }
    }
    private static void expirePending(Context c) {
        JSONArray p = arr(c, "pending"), keep = new JSONArray(); long now = System.currentTimeMillis();
        for (int i = 0; i < p.length(); i++) {
            JSONObject o = p.optJSONObject(i); if (o == null) continue;
            if (now > o.optLong("expiresAt", 0)) { cancelNote(c, o.optString("id")); log(c, false, o.optString("sym") + " " + o.optString("side") + " · approval expired"); }
            else keep.put(o);
        }
        put(c, "pending", keep);
    }

    /* ================= Acil durdurma ================= */
    /** Motoru kilitler, bekleyenleri siler, bot pozisyonlarını (all=true ise hesaptaki tüm futures pozisyonlarını) kapatır */
    static void kill(Context c, boolean all) {
        final Context app = c.getApplicationContext();
        try { JSONObject r = risk(app); r.put("mode", "off"); sp(app).edit().putString("risk", r.toString()).apply(); } catch (Exception ignored) { }
        JSONArray pe = arr(app, "pending");
        for (int i = 0; i < pe.length(); i++) cancelNote(app, pe.optJSONObject(i).optString("id"));
        put(app, "pending", new JSONArray());
        halt(app, "kill", 0);
        log(app, true, "🚨 KILL SWITCH" + (all ? " (all positions)" : " (bot positions)"));
        EX.submit(() -> {
            int n = 0, fail = 0;
            try {
                Mexc m = client(app); if (m == null) return;
                JSONArray pos = m.openPositions(null), tr = arr(app, "trades");
                for (int j = 0; j < pos.length(); j++) {
                    JSONObject p = pos.getJSONObject(j);
                    JSONObject mine = null;
                    for (int i = 0; i < tr.length(); i++) { JSONObject t = tr.getJSONObject(i); if (!t.optBoolean("closed") && t.optLong("positionId") == p.optLong("positionId")) mine = t; }
                    if (mine == null && !all) continue;
                    String mx = p.getString("symbol");
                    boolean L = p.optInt("positionType") == 1;
                    try {
                        try { m.cancelAll(mx); } catch (Exception ignored) { }
                        try { m.stopCancelAll(mx); } catch (Exception ignored) { }
                        double px = Mexc.lastPrice(mx);
                        m.submit(mx, L ? 4 : 2, p.getDouble("holdVol"), px, 0, null, p.optLong("positionId"), null);
                        if (mine != null) closed(app, mine, "KILL", px);
                        n++;
                    } catch (Exception e) { fail++; log(app, false, mx + " · kill close failed: " + e.getMessage()); }
                }
            } catch (Exception e) { fail++; log(app, false, "kill: " + e.getMessage()); }
            log(app, fail == 0, "kill done · closed " + n + (fail > 0 ? " · FAILED " + fail + " → check the exchange app!" : ""));
            note(app, "🚨 Albay Trading Bot", String.format(Locale.US, T(app, fail == 0 ? "killOk" : "killFail"), n, fail));
        });
    }
    static String resume(Context c) {
        sp(c).edit().remove("halt").apply();
        log(c, true, "halt cleared (engine stays off until a mode is chosen)");
        return "ok";
    }

    /* ================= Durum ================= */
    static String status(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("key", Vault.has(c)); o.put("mask", Vault.masked(c));
            o.put("risk", risk(c)); o.put("test", lastTest(c)); o.put("halt", halted(c));
            o.put("day", day(c)); o.put("acct", new JSONObject(sp(c).getString("acct", "{}")));
            o.put("pending", arr(c, "pending")); o.put("trades", arr(c, "trades")); o.put("log", arr(c, "log"));
            o.put("sync", sp(c).getLong("sync", 0)); if (sp(c).contains("syncErr")) o.put("syncErr", sp(c).getString("syncErr", ""));
            o.put("gateN", GATE_N); o.put("gateDD", GATE_DD); o.put("hardLev", HARD_MAX_LEV);
        } catch (Exception ignored) { }
        return o.toString();
    }

    /* ================= Gün, durdurma, günlük zarar ================= */
    private static String today() {
        Calendar k = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", k.get(Calendar.YEAR), k.get(Calendar.MONTH) + 1, k.get(Calendar.DAY_OF_MONTH));
    }
    private static long nextMidnight() {
        Calendar k = Calendar.getInstance();
        k.add(Calendar.DAY_OF_MONTH, 1); k.set(Calendar.HOUR_OF_DAY, 0); k.set(Calendar.MINUTE, 0); k.set(Calendar.SECOND, 5); k.set(Calendar.MILLISECOND, 0);
        return k.getTimeInMillis();
    }
    static synchronized JSONObject day(Context c) {
        try {
            JSONObject d = new JSONObject(sp(c).getString("day", "{}"));
            if (!today().equals(d.optString("d"))) { d = new JSONObject(); d.put("d", today()); d.put("trades", 0); put(c, "day", d); }
            return d;
        } catch (Exception e) { return new JSONObject(); }
    }
    /** Günün ilk değerine göre zarar; limit aşıldıysa gün sonuna kadar durdurur */
    private static boolean dayLossHit(Context c, JSONObject r, double eq) throws Exception {
        if (!(eq > 0)) return false;
        JSONObject d = day(c);
        if (!d.has("startEq")) { d.put("startEq", eq); put(c, "day", d); }
        double loss = d.getDouble("startEq") - eq;
        d.put("eq", eq); put(c, "day", d);
        if (loss >= r.getDouble("dayLossUsd")) {
            if (halted(c) == null) {
                halt(c, "dayLoss", nextMidnight());
                log(c, false, "daily loss limit hit: −" + usd(loss) + " → paused until midnight");
                note(c, "⛔ Albay Trading Bot", String.format(Locale.US, T(c, "dayLoss"), usd(loss)));
            }
            return true;
        }
        return false;
    }
    /** until=0 → elle kaldırılana kadar */
    private static void halt(Context c, String why, long until) {
        try { JSONObject h = new JSONObject(); h.put("why", why); h.put("t", System.currentTimeMillis()); h.put("until", until); sp(c).edit().putString("halt", h.toString()).apply(); } catch (Exception ignored) { }
    }
    static JSONObject halted(Context c) {
        try {
            String s = sp(c).getString("halt", null); if (s == null) return null;
            JSONObject h = new JSONObject(s);
            long u = h.optLong("until", 0);
            if (u > 0 && System.currentTimeMillis() > u) { sp(c).edit().remove("halt").apply(); return null; }
            return h;
        } catch (Exception e) { return null; }
    }

    /* ================= Bildirim ================= */
    private static final Map<String, Integer> NOTE_ID = new HashMap<>();
    private static int noteId(String id) { synchronized (NOTE_ID) { Integer n = NOTE_ID.get(id); if (n == null) { n = 5000 + (id.hashCode() & 0x3ff); NOTE_ID.put(id, n); } return n; } }

    private static void notifyPending(Context c, JSONObject s, JSONObject r) {
        try {
            NativeBridge.createChannels(c);
            String id = s.getString("id");
            Intent ok = new Intent(c, LiveReceiver.class).setAction(ACT_OK).putExtra("id", id);
            Intent no = new Intent(c, LiveReceiver.class).setAction(ACT_NO).putExtra("id", id);
            int rc = noteId(id);
            PendingIntent pOk = PendingIntent.getBroadcast(c, rc * 2, ok, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            PendingIntent pNo = PendingIntent.getBroadcast(c, rc * 2 + 1, no, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String sym = s.getString("sym");
            String body = String.format(Locale.US, T(c, "pendingB"), s.optString("tf"), Scanner.fmt(sym, s.getDouble("entry")), Scanner.fmt(sym, s.getDouble("stop")),
                    usd(r.getDouble("marginUsd")), r.getInt("maxLev"), r.getInt("confirmMin"));
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, NativeBridge.CH_SIGNALS)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("🟡 " + title(c, sym, s.getString("side")) + " · " + T(c, "pendingT"))
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(false).setOngoing(false)
                    .setTimeoutAfter(r.getInt("confirmMin") * 60_000L)
                    .setContentIntent(NativeBridge.openApp(c))
                    .addAction(0, T(c, "approve"), pOk)
                    .addAction(0, T(c, "reject"), pNo);
            if (NotificationManagerCompat.from(c).areNotificationsEnabled()) NotificationManagerCompat.from(c).notify(rc, b.build());
        } catch (SecurityException ignored) { } catch (Exception ignored) { }
    }
    private static void cancelNote(Context c, String id) { try { NotificationManagerCompat.from(c).cancel(noteId(id)); } catch (Exception ignored) { } }
    private static void note(Context c, String title, String body) { Notifier.post(c, title, body); }
    private static String title(Context c, String sym, String side) { return "[Futures] $" + Scanner.tick("crypto", sym) + " · " + side + " · " + T(c, "live"); }

    private static final Map<String, String[]> TX = new HashMap<>();
    static {
        //            tr, en, de
        TX.put("live", new String[]{"CANLI", "LIVE", "LIVE"});
        TX.put("pendingT", new String[]{"Onay bekliyor", "Awaiting approval", "Wartet auf Bestätigung"});
        TX.put("pendingB", new String[]{"%s · Giriş %s · Stop %s\nMarj en fazla %s · en fazla %dx · %d dk içinde onayla",
                "%s · Entry %s · Stop %s\nMargin up to %s · up to %dx · approve within %d min",
                "%s · Einstieg %s · Stopp %s\nMarge bis %s · bis %dx · innerhalb von %d Min. bestätigen"});
        TX.put("approve", new String[]{"✅ Onayla", "✅ Approve", "✅ Bestätigen"});
        TX.put("reject", new String[]{"✖ Reddet", "✖ Reject", "✖ Ablehnen"});
        TX.put("opened", new String[]{"Canlı pozisyon açıldı · %dx · marj %s\nGiriş %s · Stop %s (borsada) · risk %s",
                "Live position opened · %dx · margin %s\nEntry %s · Stop %s (on exchange) · risk %s",
                "Live-Position eröffnet · %dx · Marge %s\nEinstieg %s · Stopp %s (an der Börse) · Risiko %s"});
        TX.put("closed", new String[]{"Canlı pozisyon kapatıldı.", "Live position closed.", "Live-Position geschlossen."});
        TX.put("closedEx", new String[]{"Pozisyon borsada kapandı (stop veya elle).", "Position closed on the exchange (stop or manual).", "Position an der Börse geschlossen (Stopp oder manuell)."});
        TX.put("noStop", new String[]{"Borsada stop-loss bulunamadı, pozisyon hemen kapatıldı ve motor durduruldu. Borsa uygulamasını kontrol et.",
                "No stop-loss found on the exchange; the position was closed at once and the engine stopped. Check the exchange app.",
                "Kein Stop-Loss an der Börse gefunden; die Position wurde sofort geschlossen und die Engine gestoppt. Prüfe die Börsen-App."});
        TX.put("dayLoss", new String[]{"Günlük zarar limiti aşıldı (−%s). Canlı işlem gece yarısına kadar durduruldu.",
                "Daily loss limit reached (−%s). Live trading paused until midnight.",
                "Tagesverlustlimit erreicht (−%s). Live-Handel bis Mitternacht pausiert."});
        TX.put("killOk", new String[]{"Acil durdurma tamam: %d pozisyon kapatıldı, motor kilitli.", "Kill switch done: %d positions closed, engine locked.", "Not-Aus erledigt: %d Positionen geschlossen, Engine gesperrt."});
        TX.put("killFail", new String[]{"Acil durdurma: %d kapatıldı, %d BAŞARISIZ. Hemen borsa uygulamasını kontrol et!", "Kill switch: %d closed, %d FAILED. Check the exchange app now!", "Not-Aus: %d geschlossen, %d FEHLGESCHLAGEN. Sofort die Börsen-App prüfen!"});
    }
    private static String T(Context c, String k) {
        String l = Scanner.config(c).optString("lang", "tr");
        int i = l.equals("en") ? 1 : l.equals("de") ? 2 : 0;
        String[] v = TX.get(k); return v == null ? k : v[i];
    }

    /* ================= Yardımcılar ================= */
    private static Mexc client(Context c) { String[] k = Vault.load(c); return k == null ? null : new Mexc(k[0], k[1]); }
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    private static JSONArray arr(Context c, String k) { try { return new JSONArray(sp(c).getString(k, "[]")); } catch (Exception e) { return new JSONArray(); } }
    private static void put(Context c, String k, Object v) { sp(c).edit().putString(k, v.toString()).apply(); }
    private static void saveAccount(Context c, JSONObject u) {
        try { JSONObject a = new JSONObject(); a.put("eq", u.optDouble("equity", 0)); a.put("avail", u.optDouble("availableBalance", 0)); a.put("upnl", u.optDouble("unrealized", 0)); a.put("t", System.currentTimeMillis()); put(c, "acct", a); } catch (Exception ignored) { }
    }
    private static JSONObject findPos(JSONArray pos, String mx, boolean L) {
        for (int i = 0; i < pos.length(); i++) {
            JSONObject p = pos.optJSONObject(i);
            if (p != null && mx.equals(p.optString("symbol")) && p.optInt("positionType") == (L ? 1 : 2) && p.optDouble("holdVol", 0) > 0) return p;
        }
        return null;
    }
    private static synchronized JSONObject findTrade(Context c, String id) {
        JSONArray a = arr(c, "trades");
        for (int i = 0; i < a.length(); i++) { JSONObject t = a.optJSONObject(i); if (t != null && id.equals(t.optString("id"))) return t; }
        return null;
    }
    private static synchronized void saveTrade(Context c, JSONObject t) {
        JSONArray a = arr(c, "trades");
        try { for (int i = 0; i < a.length(); i++) if (t.getString("id").equals(a.getJSONObject(i).optString("id"))) { a.put(i, t); break; } } catch (Exception ignored) { }
        put(c, "trades", a);
    }
    private static JSONArray trimTrades(JSONArray a) {
        if (a.length() <= 200) return a;
        JSONArray out = new JSONArray();
        for (int i = a.length() - 200; i < a.length(); i++) out.put(a.opt(i));
        return out;
    }
    static synchronized void log(Context c, boolean ok, String msg) {
        try {
            JSONArray l = arr(c, "log"), out = new JSONArray();
            JSONObject o = new JSONObject(); o.put("t", System.currentTimeMillis()); o.put("ok", ok); o.put("m", msg);
            out.put(o);
            for (int i = 0; i < l.length() && i < 79; i++) out.put(l.get(i));
            put(c, "log", out);
        } catch (Exception ignored) { }
    }
    private static double roundTick(double p, double tick) {
        if (!(tick > 0)) return p;
        double r = Math.round(p / tick) * tick;
        int dec = Math.max(0, (int) Math.ceil(-Math.log10(tick)) + 1);
        return Double.parseDouble(String.format(Locale.US, "%." + Math.min(12, dec) + "f", r));
    }
    private static String usd(double v) { return String.format(Locale.US, v >= 100 ? "$%.0f" : "$%.2f", v); }
    private static String num(double v) { return v == Math.floor(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.4f", v); }
    /** Sık görülen borsa hatalarına kısa açıklama */
    private static String hint(Mexc.ApiError e) {
        switch (e.code) {
            case 602: return "602 signature failed (check key/secret)";
            case 702: case 704: return e.code + " API key has no trade permission";
            case 1002: return "1002 contract not active";
            case 2005: return "2005 not enough balance";
            default: return e.getMessage();
        }
    }
}
