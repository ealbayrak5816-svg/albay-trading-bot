package com.albay.tradingbot;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Borsa API anahtarının şifreli kasası.
 * Anahtar Android Keystore'da üretilen, cihazdan dışarı çıkarılamayan AES-256-GCM anahtarıyla şifrelenir.
 * HTML tarafı anahtarı hiçbir zaman geri okuyamaz; sadece maskelenmiş hâlini görür.
 */
final class Vault {

    private static final String ALIAS = "albay_exchange_v1";
    private static final String PREF = "albay_vault";

    private static SecretKey keyOf() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        g.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return g.generateKey();
    }

    private static String enc(String plain) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, keyOf());
        byte[] iv = c.getIV(), ct = c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }
    private static String dec(String s) throws Exception {
        String[] p = s.split(":");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, keyOf(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
    }

    static void save(Context c, String apiKey, String secret) throws Exception {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("k", enc(apiKey.trim()))
                .putString("s", enc(secret.trim()))
                .putString("mask", mask(apiKey.trim()))
                .apply();
    }
    /** {apiKey, secret} veya yoksa null */
    static String[] load(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String k = sp.getString("k", null), s = sp.getString("s", null);
        if (k == null || s == null) return null;
        try { return new String[]{dec(k), dec(s)}; } catch (Exception e) { return null; }
    }
    static boolean has(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).contains("k"); }
    static String masked(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("mask", ""); }
    static void clear(Context c) { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply(); }

    static String mask(String k) {
        if (k.length() <= 8) return "••••";
        return k.substring(0, 4) + "••••" + k.substring(k.length() - 4);
    }
}
