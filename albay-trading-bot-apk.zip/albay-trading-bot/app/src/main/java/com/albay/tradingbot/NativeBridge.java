package com.albay.tradingbot;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import androidx.core.app.NotificationManagerCompat;

import org.json.JSONObject;

/** HTML uygulamasının çağırdığı yerel köprü: window.AlbayBot */
public class NativeBridge {

    static final String CH_SIGNALS = "albay_signals";
    static final String CH_SERVICE = "albay_service";
    private final Activity activity;

    NativeBridge(Activity a) { this.activity = a; }

    static void createChannels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        NotificationChannel sig = new NotificationChannel(CH_SIGNALS, "Sinyaller", NotificationManager.IMPORTANCE_HIGH);
        sig.setDescription("Yeni sinyal, TP, runner ve stop bildirimleri");
        sig.enableVibration(true);
        nm.createNotificationChannel(sig);
        NotificationChannel svc = new NotificationChannel(CH_SERVICE, "Bot çalışıyor", NotificationManager.IMPORTANCE_LOW);
        svc.setDescription("Canlı veri takibinin arka planda sürdüğünü gösterir");
        nm.createNotificationChannel(svc);
    }

    static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /* ---- Bildirim ---- */
    @JavascriptInterface public void notify(String title, String body) { Notifier.post(activity, title, body); }
    @JavascriptInterface public void notifyOnce(String key, String title, String body) { Notifier.notifyOnce(activity, key, title, body); }
    @JavascriptInterface public boolean wasNotified(String key) { return Notifier.wasNotified(activity, key); }
    @JavascriptInterface public void markSeen(String key) { Notifier.markSeen(activity, key); }
    @JavascriptInterface public boolean notificationsEnabled() { return NotificationManagerCompat.from(activity).areNotificationsEnabled(); }
    @JavascriptInterface
    public void requestNotificationPermission() {
        activity.runOnUiThread(() -> { if (activity instanceof MainActivity) ((MainActivity) activity).askNotificationPermission(); });
    }
    @JavascriptInterface
    public void vibrate(int ms) {
        Vibrator v = activity.getSystemService(Vibrator.class);
        if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(Math.max(30, ms), VibrationEffect.DEFAULT_AMPLITUDE));
    }

    /* ---- Arka plan motoru ---- */
    @JavascriptInterface
    public void setConfig(String json) {
        activity.getSharedPreferences(Scanner.PREF, Context.MODE_PRIVATE).edit().putString("cfg", json).apply();
        BotService.scheduleNext(activity);
    }
    @JavascriptInterface public void setPositions(String json) { Scanner.mergePositions(activity, json); }
    @JavascriptInterface
    public String engineStatus() {
        JSONObject o = new JSONObject();
        try {
            SharedPreferences sp = activity.getSharedPreferences(Scanner.PREF, Context.MODE_PRIVATE);
            AlarmManager am = activity.getSystemService(AlarmManager.class);
            PowerManager pm = activity.getSystemService(PowerManager.class);
            o.put("exact", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
            o.put("battery", pm.isIgnoringBatteryOptimizations(activity.getPackageName()));
            o.put("lastScan", sp.getLong("lastScan", 0));
            o.put("scans", sp.getInt("scans", 0));
            if (sp.contains("lastError")) o.put("lastError", sp.getString("lastError", ""));
        } catch (Exception ignored) { }
        return o.toString();
    }
    @JavascriptInterface
    public void requestExactAlarm() {
        if (Build.VERSION.SDK_INT < 31) return;
        open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + activity.getPackageName())));
    }
    @JavascriptInterface
    public void requestBatteryExemption() {
        open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + activity.getPackageName())));
    }

    /* ---- Tarayıcının CORS nedeniyle çekemediği herkese açık veriler (izinli adresler) ---- */
    @JavascriptInterface
    public String httpGet(String url) {
        if (url == null || !(url.startsWith("https://nfs.faireconomy.media/") || url.startsWith("https://api.alternative.me/") || url.startsWith("https://stablecoins.llama.fi/"))) return "";
        try { return Scanner.get(url); } catch (Exception e) { return ""; }
    }

    /* ---- Dış bağlantı (TradingView) ---- */
    @JavascriptInterface public void openUrl(String url) { open(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }

    private void open(Intent i) {
        activity.runOnUiThread(() -> { try { activity.startActivity(i); } catch (Exception ignored) { } });
    }

    @JavascriptInterface public String appVersion() { return "1.3"; }
}
