package com.albay.tradingbot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon yeniden başladığında veya uygulama güncellendiğinde motoru tekrar kurar. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        BotService.ensureRunning(c);
        BotService.scheduleNext(c);
    }
}
