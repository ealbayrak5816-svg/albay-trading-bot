package com.albay.tradingbot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor("#030812"));
        getWindow().setNavigationBarColor(Color.parseColor("#030812"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#030812"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage: sinyaller, geçmiş, ayarlar
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        // Yerel sayfanın herkese açık veri servislerine (Yahoo, ForexFactory…) tarayıcı kısıtı olmadan erişmesi için
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("file".equals(u.getScheme())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, u));   // dış linkler tarayıcıda açılır
                return true;
            }
        });

        web.addJavascriptInterface(new NativeBridge(this), "AlbayBot");
        NativeBridge.createChannels(this);

        if (state != null) web.restoreState(state);
        else web.loadUrl("file:///android_asset/index.html");

        askNotificationPermission();
        startBotService();
    }

    void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }

    private void startBotService() {
        Intent i = new Intent(this, BotService.class);
        try { startForegroundService(i); } catch (Exception ignored) { }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    // Uygulama arka plana alındığında WebView duraklatılmaz: veriler ve sinyal takibi devam eder
    @Override
    protected void onPause() { super.onPause(); }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        web.resumeTimers();
        BotService.scheduleNext(this);          // izin değiştiyse alarmı yeniden kur
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else moveTaskToBack(true);              // geri tuşu uygulamayı kapatmaz, arka plana alır
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AlbayBot");
            web.destroy();
        }
        super.onDestroy();
    }
}
