package com.albay.tradingbot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Telegram sinyal grafiği: mumlar + giriş, stop ve TP seviyeleri.
 * Çizim platformdan bağımsızdır (G arayüzü); Android'de ChartAndroid kullanır.
 */
final class ChartPlot {

    interface G {
        void rect(float l, float t, float r, float b, int argb);
        void roundRect(float l, float t, float r, float b, float rad, int argb);
        void line(float x1, float y1, float x2, float y2, int argb, float w, boolean dash);
        void text(String s, float x, float y, int argb, float size, boolean bold, int align);   // align: 0 sol, 1 orta, 2 sağ; y = taban çizgisi
        float textW(String s, float size, boolean bold);
    }

    static final int BG = 0xFF0B1428, PANEL = 0xFF0F1B33, GRID = 0x22FFFFFF, MUTED = 0xFF8A9BBF, TEXT = 0xFFE8EEF9;
    static final int GREEN = 0xFF14F195, RED = 0xFFFF2E63, GOLD = 0xFFFFC93C;

    static final class In {
        String title, sub, side, entryL = "Entry", stopL = "Stop", brand = "Albay Trading Bot";
        double entry, stop; double[] tp = new double[0];
        double[][] k;                  // her mum: {o, h, l, c}
        java.util.function.DoubleFunction<String> fmt = d -> String.valueOf(d);
    }

    static void draw(G g, int W, int H, In in) {
        boolean L = "LONG".equals(in.side);
        g.rect(0, 0, W, H, BG);

        // Başlık
        float pad = 34;
        g.text(in.title, pad, 62, TEXT, 38, true, 0);
        g.text(in.sub, pad, 100, MUTED, 24, false, 0);
        String pill = in.side;
        float pw = g.textW(pill, 26, true) + 44;
        int pc = L ? GREEN : RED;
        g.roundRect(W - pad - pw, 34, W - pad, 82, 24, pc);
        g.text(pill, W - pad - pw / 2, 68, L ? 0xFF00180C : 0xFFFFFFFF, 26, true, 1);

        // Çizim alanı
        float tagW = 230;
        float pl = pad, pr = W - pad - tagW, pt = 130, pb = H - 58;
        g.roundRect(pl - 10, pt - 10, W - pad + 4, pb + 10, 18, PANEL);

        double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
        for (double[] c : in.k) { lo = Math.min(lo, c[2]); hi = Math.max(hi, c[1]); }
        List<Double> lv = new ArrayList<>();
        lv.add(in.entry); lv.add(in.stop);
        for (double t : in.tp) if (t > 0) lv.add(t);
        for (double v : lv) { lo = Math.min(lo, v); hi = Math.max(hi, v); }
        if (!(hi > lo)) { hi = lo * 1.01 + 1e-9; lo = lo * 0.99; }
        double span = hi - lo; lo -= span * 0.05; hi += span * 0.05;
        final double LO = lo, HI = hi;
        final float PT = pt, PB = pb;
        java.util.function.DoubleUnaryOperator Y = p -> PB - (p - LO) / (HI - LO) * (PB - PT);

        // Yatay ızgara
        for (int i = 0; i <= 4; i++) {
            float y = pt + (pb - pt) * i / 4f;
            g.line(pl, y, pr, y, GRID, 1, false);
            double p = HI - (HI - LO) * i / 4.0;
            g.text(in.fmt.apply(p), pr - 6, y - 6, 0x88FFFFFF, 18, false, 2);
        }

        // Mumlar: alanın %72'si, kalan sağ kısım ileriye dönük işlem bölgesi
        int n = in.k.length;
        float cw = (pr - pl) * 0.72f;
        float step = n > 0 ? cw / n : cw, body = Math.max(2f, step * 0.62f);
        float zoneL = pl + cw + step * 0.5f;

        // İşlem bölgesi: giriş→en uzak TP yeşil, giriş→stop kırmızı
        double far = in.entry;
        for (double t : in.tp) if (t > 0 && Math.abs(t - in.entry) > Math.abs(far - in.entry)) far = t;
        float ye = (float) Y.applyAsDouble(in.entry), ys = (float) Y.applyAsDouble(in.stop), yf = (float) Y.applyAsDouble(far);
        g.rect(zoneL, Math.min(ye, yf), pr, Math.max(ye, yf), 0x2214F195);
        g.rect(zoneL, Math.min(ye, ys), pr, Math.max(ye, ys), 0x26FF2E63);

        for (int i = 0; i < n; i++) {
            double[] c = in.k[i];
            float x = pl + step * i + step / 2;
            boolean up = c[3] >= c[0];
            int col = up ? GREEN : RED;
            g.line(x, (float) Y.applyAsDouble(c[1]), x, (float) Y.applyAsDouble(c[2]), col, Math.max(1.5f, step * 0.12f), false);
            float y1 = (float) Y.applyAsDouble(Math.max(c[0], c[3])), y2 = (float) Y.applyAsDouble(Math.min(c[0], c[3]));
            if (y2 - y1 < 1.5f) y2 = y1 + 1.5f;
            g.rect(x - body / 2, y1, x + body / 2, y2, col);
        }

        // Seviye çizgileri ve sağdaki etiketler (üst üste binmeyecek şekilde)
        List<float[]> tags = new ArrayList<>();       // {çizgiY}
        List<String> txt = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        addLevel(g, tags, txt, cols, in.entryL, in.entry, Y, pl, pr, GOLD, false, in);
        addLevel(g, tags, txt, cols, in.stopL, in.stop, Y, pl, pr, RED, true, in);
        for (int i = 0; i < in.tp.length; i++) if (in.tp[i] > 0) addLevel(g, tags, txt, cols, "TP" + (i + 1), in.tp[i], Y, pl, pr, GREEN, true, in);

        float th = 40, gap = 6;
        Integer[] ord = new Integer[tags.size()];
        for (int i = 0; i < ord.length; i++) ord[i] = i;
        Arrays.sort(ord, (a, b) -> Float.compare(tags.get(a)[0], tags.get(b)[0]));
        float[] ty = new float[ord.length];
        for (int j = 0; j < ord.length; j++) {
            float y = tags.get(ord[j])[0];
            if (j > 0) y = Math.max(y, ty[j - 1] + th + gap);
            ty[j] = y;
        }
        float over = ord.length > 0 ? ty[ord.length - 1] + th / 2 - (pb + 6) : 0;   // alta taşma → hepsini yukarı it
        if (over > 0) for (int j = 0; j < ty.length; j++) ty[j] -= over;
        for (int j = ord.length - 1; j >= 0; j--) {                                  // üste taşma → aşağı it
            float min = pt - 6 + th / 2 + j * (th + gap);
            if (ty[j] < min) ty[j] = min;
        }
        float tl = pr + 12, tr = W - pad - 4;
        for (int j = 0; j < ord.length; j++) {
            float[] tg = tags.get(ord[j]);
            int col = cols.get(ord[j]);
            if (Math.abs(ty[j] - tg[0]) > 1) g.line(pr, tg[0], tl, ty[j], col, 2, false);
            g.roundRect(tl, ty[j] - th / 2, tr, ty[j] + th / 2, 10, col);
            int fg = col == RED ? 0xFFFFFFFF : 0xFF0B1428;
            g.text(txt.get(ord[j]), (tl + tr) / 2, ty[j] + 8, fg, 21, true, 1);
        }

        g.text(in.brand, pad, H - 20, 0x66FFFFFF, 20, true, 0);
    }

    private static void addLevel(G g, List<float[]> tags, List<String> txt, List<Integer> cols, String name, double p,
                                 java.util.function.DoubleUnaryOperator Y, float pl, float pr, int col, boolean dash, In in) {
        float y = (float) Y.applyAsDouble(p);
        g.line(pl, y, pr, y, col, dash ? 2 : 3, dash);
        tags.add(new float[]{y});
        cols.add(col);
        txt.add(name + "  " + in.fmt.apply(p));
    }
}
