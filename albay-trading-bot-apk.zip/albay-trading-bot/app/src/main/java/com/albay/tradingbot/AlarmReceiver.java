package com.albay.tradingbot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Mum kapanışı alarmı: arka plan taramasını başlatır. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        BotService.ensureRunning(c);
        BotService.scanNow(c);
    }
}
