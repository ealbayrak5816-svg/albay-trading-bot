# Albay Trading Bot (Android)

Bu proje, Albay Trading Bot web uygulamasını (`app/src/main/assets/index.html`) bir Android APK’ya çevirir.
Paket adı `com.albay.tradingbot`; eski "Albay Trading" uygulamasından ayrıdır, ikisi aynı telefonda yan yana çalışır.

## APK nasıl alınır (GitHub Actions)
1. GitHub’da yeni bir depo oluştur (ör. `albay-trading-bot`).
2. Bu klasördeki her şeyi (gizli `.github` klasörü dahil) depoya yükle.
3. Depoda **Actions** sekmesini aç → "Albay Trading Bot APK" iş akışı otomatik başlar
   (başlamazsa "Run workflow" ile elle başlat).
4. Bitince çalışmaya tıkla → en alttaki **Artifacts** bölümünden `AlbayTradingBot` dosyasını indir,
   zip’i aç ve `AlbayTradingBot.apk`’yı telefona kur.

## Güncelleme
Yalnızca `app/src/main/assets/index.html` dosyasını yeni sürümle değiştirip yükle.
APK hep aynı anahtarla imzalandığı için yeni sürüm eskisinin üstüne kurulur; sinyaller, geçmiş ve ayarlar silinmez.
`app/build.gradle` içindeki `versionCode` değerini her sürümde 1 artırman iyi olur.

## Telefonda ilk ayarlar
- Bildirim iznine **İzin ver** de.
- Ayarlar → Uygulamalar → Albay Trading Bot → Pil → **Kısıtlama yok** seç.
  Böylece uygulama arka plandayken veri akışı ve sinyal takibi kesilmez.
- Uygulamayı geri tuşuyla değil, ana ekran tuşuyla arka plana al; son uygulamalardan kaydırıp kapatırsan takip durur.

## Önemli
`app/albay-bot.jks` imza anahtarıdır, silme ve kaybetme. Kaybolursa yeni APK eskisinin üstüne kurulamaz.
