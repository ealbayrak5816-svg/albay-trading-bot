package com.albay.tradingbot;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * Bot sinyallerini Telegram grubuna/kanalına gönderir.
 * Uygulama ve arka plan motoru aynı anahtarı kullanır; aynı olay gruba asla iki kez gitmez.
 */
final class Telegram {

    private static final String PREF = "albay_tg";
    private static final int MAX = 1500;
    private static LinkedHashSet<String> sent;

    private static synchronized void load(Context c) {
        if (sent != null) return;
        sent = new LinkedHashSet<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("sent", "[]"));
            for (int i = 0; i < a.length(); i++) sent.add(a.getString(i));
        } catch (Exception ignored) { }
    }
    private static void persist(Context c) {
        Iterator<String> it = sent.iterator();
        while (sent.size() > MAX && it.hasNext()) { it.next(); it.remove(); }
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("sent", new JSONArray(sent).toString()).apply();
    }
    /** Anahtar daha önce gönderilmediyse işaretler ve true döner */
    private static synchronized boolean claim(Context c, String key) { load(c); if (!sent.add(key)) return false; persist(c); return true; }
    private static synchronized void release(Context c, String key) { load(c); if (sent.remove(key)) persist(c); }

    static String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    static void maybe(Context c, JSONObject cfg, String mk, String ev, boolean strong, String key, String html) {
        maybe(c, cfg, mk, ev, strong, key, html, null);
    }

    /**
     * Ayarlara göre gönderilip gönderilmeyeceğine karar verir.
     * ev: "new" (yeni sinyal), "tp" (TP1/TP2/runner), "close" (stop, TP3, runner çıkışı, süre doldu)
     * meta: new → {id, mk, sym, tf, side, entry, stop, tp:[..]} (grafik + rapor kaydı);
     *       tp/close → aynı seviyeler + hit:{tp, sl, st, sc} (vurulan seviyeler ✓/✕ ile aynı grafik, ilk mesaja yanıt);
     *       close ayrıca {r, pct} (rapor sonucu)
     */
    static void maybe(Context c, JSONObject cfg, String mk, String ev, boolean strong, String key, String html, JSONObject meta) {
        JSONObject tg = cfg == null ? null : cfg.optJSONObject("tg");
        if (tg == null || !tg.optBoolean("on", false)) return;
        String token = tg.optString("token", "").trim(), chat = tg.optString("chat", "").trim();
        if (token.isEmpty() || chat.isEmpty() || key == null || key.isEmpty()) return;
        JSONObject mks = tg.optJSONObject("mk");
        if (mks != null && !mks.optBoolean(mk, true)) return;
        // Rapor: gruba gönderilmiş bir sinyal kapandıysa sonucu kaydet (kapanış mesajları kapalı olsa bile)
        if (ev.equals("close") && meta != null) recordClose(c, meta);
        if (ev.equals("new") && tg.optBoolean("strong", false) && !strong) return;
        if (ev.equals("tp") && !tg.optBoolean("tp", true)) return;
        if (ev.equals("close") && !tg.optBoolean("close", true)) return;
        final String k = "tg|" + key;
        String disc = tg.optString("disc", "");
        if (html == null || html.isEmpty()) return;
        final String text = html + (disc.isEmpty() ? "" : "\n\n<i>" + esc(disc) + "</i>");
        if (!claim(c, k)) return;
        final Context app = c.getApplicationContext();
        // Grafik: yeni sinyalde ve (seviyeler meta'da varsa) TP/stop güncellemelerinde; güncellemede vurulan seviyeler işaretli
        final boolean levels = meta != null && meta.has("entry") && meta.has("tp");
        final boolean chart = levels && tg.optBoolean("chart", true) && (ev.equals("new") || ev.equals("tp") || ev.equals("close"));
        final boolean isNew = ev.equals("new") && meta != null;
        final String gid = meta == null ? "" : meta.optString("id", "");
        final long replyTo = isNew || gid.isEmpty() ? 0 : msgId(app, gid);   // güncelleme ilk sinyal mesajına yanıt olarak gider
        new Thread(() -> {
            try {
                String res = null;
                if (chart) {
                    try {
                        byte[] png = ChartAndroid.renderOrThrow(app, cfg, meta);
                        if (text.length() <= 1000) res = sendPhoto(token, chat, png, text, replyTo);
                        else { res = sendPhoto(token, chat, png, null, replyTo); send(token, chat, text, replyTo); }
                        chartLog(app, null);
                    } catch (Throwable e) { res = null; chartLog(app, e); }   // grafik gitmezse düz metinle dene, hatayı kaydet
                }
                if (res == null) res = send(token, chat, text, replyTo);
                if (isNew) { recordOpen(app, meta); saveMsgId(app, gid, parseMsgId(res)); }
                if (ev.equals("close") && !gid.isEmpty()) saveMsgId(app, gid, 0);
            }
            catch (Exception e) { release(app, k); }                 // başarısızsa tekrar denenebilsin
        }).start();
    }

    /* ---- Sinyal → gruptaki ilk mesajın kimliği (güncellemeler yanıt olarak bağlansın diye) ---- */
    private static synchronized JSONObject msgMap(Context c) {
        try { return new JSONObject(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("msg", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    static synchronized long msgId(Context c, String id) { JSONObject m = msgMap(c).optJSONObject(id); return m == null ? 0 : m.optLong("m", 0); }
    static synchronized void saveMsgId(Context c, String id, long mid) {
        if (id == null || id.isEmpty()) return;
        try {
            JSONObject m = msgMap(c);
            if (mid > 0) { JSONObject o = new JSONObject(); o.put("m", mid); o.put("t", System.currentTimeMillis()); m.put(id, o); }
            else m.remove(id);
            long cut = System.currentTimeMillis() - 30 * 86_400_000L;          // 30 günden eski kayıtlar silinir
            JSONArray names = m.names();
            if (names != null) for (int i = 0; i < names.length(); i++) {
                JSONObject o = m.optJSONObject(names.getString(i));
                if (o == null || o.optLong("t", 0) < cut) m.remove(names.getString(i));
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("msg", m.toString()).apply();
        } catch (Exception ignored) { }
    }
    private static long parseMsgId(String res) {
        try { JSONObject r = new JSONObject(res).optJSONObject("result"); return r == null ? 0 : r.optLong("message_id", 0); }
        catch (Exception e) { return 0; }
    }
    private static String replyJson(long replyTo) { return "{\"message_id\":" + replyTo + ",\"allow_sending_without_reply\":true}"; }

    /** Son grafik denemesinin sonucu (teşhis panelinde görünür) */
    static void chartLog(Context c, Throwable e) {
        SharedPreferences.Editor ed = c.getSharedPreferences(REP, Context.MODE_PRIVATE).edit().putLong("chartT", System.currentTimeMillis());
        if (e == null) ed.remove("chartErr"); else ed.putString("chartErr", e.getClass().getSimpleName() + ": " + e.getMessage());
        ed.apply();
    }
    static String chartStatus(Context c) {
        SharedPreferences sp = c.getSharedPreferences(REP, Context.MODE_PRIVATE);
        try {
            JSONObject o = new JSONObject();
            o.put("t", sp.getLong("chartT", 0));
            if (sp.contains("chartErr")) o.put("err", sp.getString("chartErr", ""));
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }
    /** Test: BTC 15m için örnek seviyelerle grafik gönderir; Telegram cevabını ya da hatayı döner */
    static String chartTest(Context c) {
        JSONObject cfg = Scanner.config(c), tg = cfg.optJSONObject("tg");
        String token = tg == null ? "" : tg.optString("token", "").trim(), chat = tg == null ? "" : tg.optString("chat", "").trim();
        try {
            List<Engine.C> k = Scanner.fetchCandles(c, "crypto", "BTCUSDT", "15m", 70);
            double p = k.get(k.size() - 1).c, r = p * 0.006;
            JSONObject meta = new JSONObject();
            meta.put("mk", "crypto"); meta.put("sym", "BTCUSDT"); meta.put("tf", "15m"); meta.put("side", "LONG");
            meta.put("entry", p); meta.put("stop", p - r);
            JSONArray tp = new JSONArray(); tp.put(p + r); tp.put(p + 2 * r); tp.put(p + 3 * r); meta.put("tp", tp);
            byte[] png = ChartAndroid.renderOrThrow(c, cfg, meta);
            String res = sendPhoto(token, chat, png, "🧪 <b>Albay Trading Bot</b> · chart test (BTC/USDT 15m)");
            chartLog(c, null);
            return res;
        } catch (Throwable e) {
            chartLog(c, e);
            String m = String.valueOf(e.getMessage());
            if (m.startsWith("{")) return m;
            return "{\"ok\":false,\"description\":\"" + esc(e.getClass().getSimpleName() + ": " + m).replace("\"", "'").replace("\n", " ") + "\"}";
        }
    }

    /** Fotoğraf + açıklama (multipart) */
    static String sendPhoto(String token, String chat, byte[] png, String captionHtml) throws Exception { return sendPhoto(token, chat, png, captionHtml, 0); }
    static String sendPhoto(String token, String chat, byte[] png, String captionHtml, long replyTo) throws Exception {
        String bd = "----albay" + System.nanoTime();
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/sendPhoto").openConnection();
        c.setConnectTimeout(10_000); c.setReadTimeout(30_000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + bd);
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        field(body, bd, "chat_id", chat);
        if (captionHtml != null) { field(body, bd, "caption", captionHtml); field(body, bd, "parse_mode", "HTML"); }
        if (replyTo > 0) field(body, bd, "reply_parameters", replyJson(replyTo));
        body.write(("--" + bd + "\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"signal.png\"\r\nContent-Type: image/png\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        body.write(png);
        body.write(("\r\n--" + bd + "--\r\n").getBytes(StandardCharsets.UTF_8));
        try (OutputStream os = c.getOutputStream()) { body.writeTo(os); }
        return finish(c);
    }
    private static void field(ByteArrayOutputStream b, String bd, String name, String val) throws Exception {
        b.write(("--" + bd + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        b.write(val.getBytes(StandardCharsets.UTF_8));
        b.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }
    private static String finish(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String res = "";
        if (in != null) {
            try (InputStream is = in) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                res = new String(bo.toByteArray(), StandardCharsets.UTF_8);
            }
        }
        c.disconnect();
        if (code != 200) throw new Exception(res.isEmpty() ? "HTTP " + code : res);
        return res;
    }

    /* ---------------- Rapor kaydı: sadece gruba gönderilen sinyaller ---------------- */
    private static final String REP = "albay_tgrep";
    private static final long DAY = 86_400_000L;

    private static JSONArray log(Context c) {
        try { return new JSONArray(c.getSharedPreferences(REP, Context.MODE_PRIVATE).getString("log", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private static void saveLog(Context c, JSONArray a) {
        long cut = System.currentTimeMillis() - 40 * DAY;
        JSONArray out = new JSONArray();
        int start = Math.max(0, a.length() - 3000);
        for (int i = start; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (o.optLong("t", 0) < cut && (o.has("ct") || o.optLong("t", 0) < cut - 20 * DAY)) continue;
            out.put(o);
        }
        c.getSharedPreferences(REP, Context.MODE_PRIVATE).edit().putString("log", out.toString()).apply();
    }
    static synchronized void recordOpen(Context c, JSONObject meta) {
        try {
            String id = meta.optString("id");
            if (id.isEmpty()) return;
            JSONArray a = log(c);
            for (int i = a.length() - 1; i >= 0; i--) { JSONObject o = a.getJSONObject(i); if (id.equals(o.optString("id")) && !o.has("ct")) return; }
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("sym", meta.optString("sym")); o.put("side", meta.optString("side")); o.put("t", System.currentTimeMillis());
            a.put(o); saveLog(c, a);
        } catch (Exception ignored) { }
    }
    static synchronized void recordClose(Context c, JSONObject meta) {
        try {
            String id = meta.optString("id");
            double r = meta.optDouble("r", Double.NaN), pct = meta.optDouble("pct", Double.NaN);
            if (id.isEmpty() || Double.isNaN(r)) return;
            JSONArray a = log(c);
            for (int i = a.length() - 1; i >= 0; i--) {
                JSONObject o = a.getJSONObject(i);
                if (!id.equals(o.optString("id")) || o.has("ct")) continue;
                o.put("ct", System.currentTimeMillis()); o.put("r", r); o.put("pct", Double.isNaN(pct) ? 0 : pct);
                saveLog(c, a);
                return;
            }
        } catch (Exception ignored) { }
    }

    /* ---------------- Günlük / haftalık rapor ---------------- */
    private static final java.util.concurrent.atomic.AtomicBoolean reporting = new java.util.concurrent.atomic.AtomicBoolean(false);

    private static String L(JSONObject tg, String k, String def) { JSONObject L = tg.optJSONObject("L"); return L == null ? def : L.optString(k, def); }
    private static String pct(double d) { return (d >= 0 ? "+" : "−") + String.format(Locale.US, "%.2f", Math.abs(d)) + "%"; }

    static String reportHtml(Context c, JSONObject tg, boolean weekly) {
        long now = System.currentTimeMillis(), from = now - (weekly ? 7 : 1) * DAY;
        JSONArray a = log(c);
        int opened = 0, w = 0, l = 0, f = 0, open = 0;
        double sum = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            long t = o.optLong("t", 0);
            if (t >= from) opened++;
            if (!o.has("ct")) { if (t >= now - 30 * DAY) open++; continue; }
            if (o.optLong("ct", 0) < from) continue;
            double r = o.optDouble("r", 0);
            if (r >= 0.05) w++; else if (r <= -0.05) l++; else f++;
            sum += o.optDouble("pct", 0);
        }
        int closed = w + l + f;
        String date = new java.text.SimpleDateFormat("dd.MM.yyyy", Locale.US).format(new java.util.Date(now));
        StringBuilder b = new StringBuilder();
        b.append("📊 <b>").append(esc(L(tg, weekly ? "rpW" : "rpD", weekly ? "Haftalık rapor" : "Günlük rapor"))).append("</b> · ").append(date).append("\n")
         .append("<i>").append(esc(L(tg, weekly ? "rp7" : "rp24", weekly ? "Son 7 gün" : "Son 24 saat"))).append("</i>\n\n")
         .append("📨 ").append(esc(L(tg, "rpOpened", "Açılan işlem"))).append(": <b>").append(opened).append("</b>\n")
         .append("🏁 ").append(esc(L(tg, "rpClosed", "Kapanan işlem"))).append(": <b>").append(closed).append("</b>\n");
        if (closed > 0) {
            b.append("✅ ").append(esc(L(tg, "rpWin", "Kazanan"))).append(": <b>").append(w).append("</b>\n")
             .append("❌ ").append(esc(L(tg, "rpLoss", "Kaybeden"))).append(": <b>").append(l).append("</b>\n");
            if (f > 0) b.append("➖ ").append(esc(L(tg, "rpFlat", "Başabaş"))).append(": <b>").append(f).append("</b>\n");
            double wr = (w + l) > 0 ? w * 100.0 / (w + l) : 0;
            b.append("🎯 ").append(esc(L(tg, "rpRate", "Başarı oranı"))).append(": <b>").append(String.format(Locale.US, "%.1f", wr)).append("%</b>\n")
             .append("💰 ").append(esc(L(tg, "rpTot", "Toplam kâr"))).append(": <b>").append(pct(sum)).append("</b>\n")
             .append("📈 ").append(esc(L(tg, "rpAvg", "İşlem başına ortalama"))).append(": <b>").append(pct(sum / closed)).append("</b>\n");
        } else b.append("\n").append(esc(L(tg, "rpNone", "Bu dönemde kapanan işlem yok."))).append("\n");
        b.append("⏳ ").append(esc(L(tg, "rpOpen", "Hâlâ açık"))).append(": <b>").append(open).append("</b>");
        if (closed > 0) b.append("\n\n<i>").append(esc(L(tg, "rpNote", "Yüzdeler kaldıraçsız fiyat hareketidir."))).append("</i>");
        String disc = tg.optString("disc", "");
        if (!disc.isEmpty()) b.append("\n<i>").append(esc(disc)).append("</i>");
        return b.toString();
    }

    /** Test butonu: raporu hemen gönderir; Telegram cevabını döner */
    static String reportNow(Context c, boolean weekly) {
        JSONObject tg = Scanner.config(c).optJSONObject("tg");
        if (tg == null) return "{\"ok\":false}";
        try { return send(tg.optString("token", "").trim(), tg.optString("chat", "").trim(), reportHtml(c, tg, weekly)); }
        catch (Exception e) {
            String m = String.valueOf(e.getMessage());
            return m.startsWith("{") ? m : "{\"ok\":false,\"description\":\"" + esc(m).replace("\"", "'") + "\"}";
        }
    }

    /** Arka plan döngüsünden ve taramadan çağrılır: zamanı gelen raporu bir kez gönderir */
    static void reportTick(Context c) {
        if (!reporting.compareAndSet(false, true)) return;
        try {
            JSONObject tg = Scanner.config(c).optJSONObject("tg");
            if (tg == null || !tg.optBoolean("on", false)) return;
            String token = tg.optString("token", "").trim(), chat = tg.optString("chat", "").trim();
            if (token.isEmpty() || chat.isEmpty()) return;
            JSONObject rep = tg.optJSONObject("rep");
            boolean daily = rep == null || rep.optBoolean("daily", true), weekly = rep == null || rep.optBoolean("weekly", true);
            int hour = rep == null ? 21 : rep.optInt("hour", 21);
            SharedPreferences sp = c.getSharedPreferences(REP, Context.MODE_PRIVATE);
            long now = System.currentTimeMillis();
            if (now < sp.getLong("wait", 0)) return;
            java.util.Calendar cal = java.util.Calendar.getInstance();
            String today = new java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.getTime());
            boolean due = cal.get(java.util.Calendar.HOUR_OF_DAY) >= hour;
            if (!sp.contains("since")) {                                   // ilk kurulum: bugünün saati geçtiyse ilk rapor yarın
                SharedPreferences.Editor e = sp.edit().putLong("since", now);
                if (due) e.putString("lastD", today).putString("lastW", today);
                e.apply(); return;
            }
            if (!due) return;
            if (daily && !today.equals(sp.getString("lastD", ""))) {
                try { send(token, chat, reportHtml(c, tg, false)); sp.edit().putString("lastD", today).apply(); }
                catch (Exception e) { sp.edit().putLong("wait", now + 5 * 60_000L).apply(); return; }
            }
            if (weekly && cal.get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.SUNDAY && !today.equals(sp.getString("lastW", ""))) {
                try { send(token, chat, reportHtml(c, tg, true)); sp.edit().putString("lastW", today).apply(); }
                catch (Exception e) { sp.edit().putLong("wait", now + 5 * 60_000L).apply(); }
            }
        } catch (Exception ignored) {
        } finally { reporting.set(false); }
    }

    /** Senkron gönderim (test butonu); Telegram'ın JSON cevabını döner */
    static String send(String token, String chat, String html) throws Exception { return send(token, chat, html, 0); }
    static String send(String token, String chat, String html, long replyTo) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/sendMessage").openConnection();
        c.setConnectTimeout(10_000); c.setReadTimeout(15_000);
        c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        String form = "chat_id=" + URLEncoder.encode(chat, "UTF-8")
            + "&parse_mode=HTML&disable_web_page_preview=true&text=" + URLEncoder.encode(html, "UTF-8")
            + (replyTo > 0 ? "&reply_parameters=" + URLEncoder.encode(replyJson(replyTo), "UTF-8") : "");
        try (OutputStream os = c.getOutputStream()) { os.write(form.getBytes(StandardCharsets.UTF_8)); }
        return finish(c);
    }

    /** Uygulamadaki test ve "grup kimliğini bul" butonları için basit GET */
    static String call(String token, String method) {
        try { return Scanner.get("https://api.telegram.org/bot" + token + "/" + method); }
        catch (Exception e) { return "{\"ok\":false,\"description\":\"" + esc(String.valueOf(e.getMessage())).replace("\"", "'") + "\"}"; }
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
}
